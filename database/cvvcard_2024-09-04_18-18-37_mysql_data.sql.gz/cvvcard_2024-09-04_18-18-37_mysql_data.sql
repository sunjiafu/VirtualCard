-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: cvvcard
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_has_roles`
--

DROP TABLE IF EXISTS `admin_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_has_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` bigint(20) unsigned NOT NULL,
  `admin_role_id` bigint(20) unsigned NOT NULL,
  `last_edit_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_has_roles_admin_id_foreign` (`admin_id`),
  KEY `admin_has_roles_admin_role_id_foreign` (`admin_role_id`),
  KEY `admin_has_roles_last_edit_by_foreign` (`last_edit_by`),
  CONSTRAINT `admin_has_roles_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `admin_has_roles_admin_role_id_foreign` FOREIGN KEY (`admin_role_id`) REFERENCES `admin_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `admin_has_roles_last_edit_by_foreign` FOREIGN KEY (`last_edit_by`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_has_roles`
--

LOCK TABLES `admin_has_roles` WRITE;
/*!40000 ALTER TABLE `admin_has_roles` DISABLE KEYS */;
INSERT INTO `admin_has_roles` VALUES (1,1,1,1,'2024-09-02 23:57:50','2024-09-02 23:57:50');
/*!40000 ALTER TABLE `admin_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_login_logs`
--

DROP TABLE IF EXISTS `admin_login_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_login_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` bigint(20) unsigned NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mac` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_login_logs_admin_id_foreign` (`admin_id`),
  CONSTRAINT `admin_login_logs_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_login_logs`
--

LOCK TABLES `admin_login_logs` WRITE;
/*!40000 ALTER TABLE `admin_login_logs` DISABLE KEYS */;
INSERT INTO `admin_login_logs` VALUES (1,1,'103.36.25.45','','Chang-hua','Taiwan','120.54','24.0676','Chrome','Windows','Asia/Taipei','2024-09-02 23:58:30','2024-09-02 23:58:30'),(2,1,'103.36.25.45','','Chang-hua','Taiwan','120.54','24.0676','Edge','Windows','Asia/Taipei','2024-09-03 00:22:26','2024-09-03 00:22:26'),(3,1,'119.164.150.225','','Weifang','China','119.162','36.7069','Chrome','OS X','Asia/Shanghai','2024-09-03 05:12:48','2024-09-03 05:12:48'),(4,1,'119.164.150.225','','Weifang','China','119.162','36.7069','Chrome','OS X','Asia/Shanghai','2024-09-03 05:54:18','2024-09-03 05:54:18'),(5,1,'103.36.25.45','','Chang-hua','Taiwan','120.54','24.0676','Edge','Windows','Asia/Taipei','2024-09-03 11:56:08','2024-09-03 11:56:08');
/*!40000 ALTER TABLE `admin_login_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_notifications`
--

DROP TABLE IF EXISTS `admin_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` bigint(20) unsigned NOT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_notifications_admin_id_foreign` (`admin_id`),
  CONSTRAINT `admin_notifications_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_notifications`
--

LOCK TABLES `admin_notifications` WRITE;
/*!40000 ALTER TABLE `admin_notifications` DISABLE KEYS */;
INSERT INTO `admin_notifications` VALUES (1,1,'SIDE_NAV','{\"title\":\"lariena sun(admin) logged in.\",\"time\":\"1 second ago\",\"image\":\"https:\\/\\/velixpay.com\\/public\\/backend\\/images\\/default\\/default.webp\"}','2024-09-02 23:58:30','2024-09-02 23:58:30'),(2,1,'SIDE_NAV','{\"title\":\"lariena sun(admin) logged in.\",\"time\":\"1 second ago\",\"image\":\"https:\\/\\/velixpay.com\\/public\\/backend\\/images\\/default\\/default.webp\"}','2024-09-03 00:22:26','2024-09-03 00:22:26'),(3,1,'SIDE_NAV','{\"title\":\"lariena sun(admin) logged in.\",\"time\":\"1 second ago\",\"image\":\"https:\\/\\/www.velixpay.com\\/public\\/backend\\/images\\/default\\/default.webp\"}','2024-09-03 05:12:48','2024-09-03 05:12:48'),(4,1,'SIDE_NAV','{\"title\":\"lariena sun(admin) logged in.\",\"time\":\"1 second ago\",\"image\":\"https:\\/\\/www.velixpay.com\\/public\\/backend\\/images\\/default\\/default.webp\"}','2024-09-03 05:54:18','2024-09-03 05:54:18'),(5,1,'SIDE_NAV','{\"title\":\"lariena sun(admin) logged in.\",\"time\":\"1 second ago\",\"image\":\"https:\\/\\/velixpay.com\\/public\\/backend\\/images\\/default\\/default.webp\"}','2024-09-03 11:56:08','2024-09-03 11:56:08');
/*!40000 ALTER TABLE `admin_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_password_resets`
--

DROP TABLE IF EXISTS `admin_password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_password_resets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_password_resets`
--

LOCK TABLES `admin_password_resets` WRITE;
/*!40000 ALTER TABLE `admin_password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_has_permissions`
--

DROP TABLE IF EXISTS `admin_role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_has_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `admin_role_permission_id` bigint(20) unsigned NOT NULL,
  `route` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_edit_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_role_has_permissions_admin_role_permission_id_foreign` (`admin_role_permission_id`),
  KEY `admin_role_has_permissions_last_edit_by_foreign` (`last_edit_by`),
  CONSTRAINT `admin_role_has_permissions_admin_role_permission_id_foreign` FOREIGN KEY (`admin_role_permission_id`) REFERENCES `admin_role_permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `admin_role_has_permissions_last_edit_by_foreign` FOREIGN KEY (`last_edit_by`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_has_permissions`
--

LOCK TABLES `admin_role_has_permissions` WRITE;
/*!40000 ALTER TABLE `admin_role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_permissions`
--

DROP TABLE IF EXISTS `admin_role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `admin_role_id` bigint(20) unsigned NOT NULL,
  `admin_id` bigint(20) unsigned NOT NULL,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_role_permissions_name_unique` (`name`),
  UNIQUE KEY `admin_role_permissions_slug_unique` (`slug`),
  KEY `admin_role_permissions_admin_role_id_foreign` (`admin_role_id`),
  KEY `admin_role_permissions_admin_id_foreign` (`admin_id`),
  CONSTRAINT `admin_role_permissions_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `admin_role_permissions_admin_role_id_foreign` FOREIGN KEY (`admin_role_id`) REFERENCES `admin_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_permissions`
--

LOCK TABLES `admin_role_permissions` WRITE;
/*!40000 ALTER TABLE `admin_role_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_roles`
--

DROP TABLE IF EXISTS `admin_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` bigint(20) unsigned NOT NULL,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_roles_name_unique` (`name`),
  KEY `admin_roles_admin_id_foreign` (`admin_id`),
  CONSTRAINT `admin_roles_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_roles`
--

LOCK TABLES `admin_roles` WRITE;
/*!40000 ALTER TABLE `admin_roles` DISABLE KEYS */;
INSERT INTO `admin_roles` VALUES (1,1,'Super Admin',1,'2024-09-02 23:57:49','2024-09-02 23:57:49'),(2,1,'Sub Admin',1,'2024-09-02 23:57:49','2024-09-02 23:57:49'),(3,1,'Moderator',1,'2024-09-02 23:57:49','2024-09-02 23:57:49'),(4,1,'Editor',1,'2024-09-02 23:57:49','2024-09-02 23:57:49'),(5,1,'Support Team',1,'2024-09-02 23:57:49','2024-09-02 23:57:49'),(6,1,'IT Specialist',1,'2024-09-02 23:57:49','2024-09-02 23:57:49');
/*!40000 ALTER TABLE `admin_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ADMIN',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip_postal` int(11) DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `device_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `device_info` text COLLATE utf8mb4_unicode_ci,
  `last_logged_in` timestamp NULL DEFAULT NULL,
  `last_logged_out` timestamp NULL DEFAULT NULL,
  `login_status` tinyint(1) NOT NULL DEFAULT '0',
  `notification_clear_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `admin_role_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_image_unique` (`image`),
  KEY `admins_username_index` (`username`),
  KEY `admins_email_index` (`email`),
  KEY `admins_phone_index` (`phone`),
  KEY `admins_admin_role_id_foreign` (`admin_role_id`),
  CONSTRAINT `admins_admin_role_id_foreign` FOREIGN KEY (`admin_role_id`) REFERENCES `admin_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'lariena','sun','admin','ADMIN','sjf110@gmail.com','$2y$10$w5aDqj20pl0Ra38mpIhCi.bjzDk6AC288/8VKZYU1qca41G//YZme',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'2024-09-03 11:56:09',NULL,1,NULL,'2024-09-02 23:57:49','2024-09-03 11:56:09',1),(2,'Ward','Pollich','sanford.dana','ADMIN','elijah36@howe.com','$2y$10$sPQwEm4wLVcK0DzgSKQpKuwb0a2eC1Sm0K9MFN1ojRwC31/nmqyuG',NULL,NULL,NULL,NULL,'+1-657-881-2292',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,'2024-09-02 23:57:49','2024-09-02 23:57:49',NULL),(3,'Linnie','Turcotte','mayert.clare','ADMIN','umarquardt@gmail.com','$2y$10$IGMltelN7JYN.ceYvup3g.DjiYo34G3WPD1cK5B2Uk/nS7x00gMZW',NULL,NULL,NULL,NULL,'(260) 316-0827',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,'2024-09-02 23:57:49','2024-09-02 23:57:49',NULL);
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_onboard_screens`
--

DROP TABLE IF EXISTS `app_onboard_screens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_onboard_screens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `last_edit_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_onboard_screens_image_unique` (`image`),
  KEY `app_onboard_screens_last_edit_by_foreign` (`last_edit_by`),
  CONSTRAINT `app_onboard_screens_last_edit_by_foreign` FOREIGN KEY (`last_edit_by`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_onboard_screens`
--

LOCK TABLES `app_onboard_screens` WRITE;
/*!40000 ALTER TABLE `app_onboard_screens` DISABLE KEYS */;
INSERT INTO `app_onboard_screens` VALUES (1,'Create Unlimited Virtual Cards for Unlimited Usage','Users can easily create virtual credit cards from here. Use anytime anywhere and unlimited. Thanks for start a new journey with StripCard.','seeder/Onboard1.png',1,1,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(2,'Easy, Quick & Secure System for Create Virtual Card','StripCard has the most secure system which is very useful for money transactions. Get ready to use unlimited virtual credit card system.','seeder/Onboard2.png',1,1,'2024-09-02 23:57:50','2024-09-02 23:57:50');
/*!40000 ALTER TABLE `app_onboard_screens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_settings`
--

DROP TABLE IF EXISTS `app_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `splash_screen_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `android_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iso_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_settings`
--

LOCK TABLES `app_settings` WRITE;
/*!40000 ALTER TABLE `app_settings` DISABLE KEYS */;
INSERT INTO `app_settings` VALUES (1,'3.6.0','seeder/splash_screen.png','App Url','https://play.google.com/store','https://www.apple.com/app-store','2024-09-02 23:57:50','2024-09-02 23:57:50');
/*!40000 ALTER TABLE `app_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basic_settings`
--

DROP TABLE IF EXISTS `basic_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basic_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `site_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_color` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondary_color` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_exp_seconds` int(11) DEFAULT NULL,
  `timezone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_registration` tinyint(1) NOT NULL DEFAULT '1',
  `secure_password` tinyint(1) NOT NULL DEFAULT '0',
  `agree_policy` tinyint(1) NOT NULL DEFAULT '0',
  `force_ssl` tinyint(1) NOT NULL DEFAULT '0',
  `email_verification` tinyint(1) NOT NULL DEFAULT '0',
  `sms_verification` tinyint(1) NOT NULL DEFAULT '0',
  `email_notification` tinyint(1) NOT NULL DEFAULT '0',
  `push_notification` tinyint(1) NOT NULL DEFAULT '0',
  `kyc_verification` tinyint(1) NOT NULL DEFAULT '0',
  `site_logo_dark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_fav_dark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_fav` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mail_config` text COLLATE utf8mb4_unicode_ci,
  `mail_activity` text COLLATE utf8mb4_unicode_ci,
  `push_notification_config` text COLLATE utf8mb4_unicode_ci,
  `push_notification_activity` text COLLATE utf8mb4_unicode_ci,
  `broadcast_config` text COLLATE utf8mb4_unicode_ci,
  `broadcast_activity` text COLLATE utf8mb4_unicode_ci,
  `sms_config` text COLLATE utf8mb4_unicode_ci,
  `sms_activity` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `web_version` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basic_settings`
--

LOCK TABLES `basic_settings` WRITE;
/*!40000 ALTER TABLE `basic_settings` DISABLE KEYS */;
INSERT INTO `basic_settings` VALUES (1,'VelixPay','可靠的虚拟卡管理平台｜ Virtual Credit Card Solution','#635BFF','#ea5455',3600,'Asia/Dhaka',1,0,1,0,1,0,1,1,0,'1b00ef4e-a493-4810-934e-dac28fc7b805.webp','4ebec572-fca0-4109-a936-c008411f38fc.webp','589e744c-88b8-4935-8c53-39395e4d91c8.webp','2659b908-9a51-4790-91bf-2d722a57b596.webp','{\"method\":\"smtp\",\"host\":\"smtp.qiye.aliyun.com\",\"port\":\"465\",\"encryption\":\"ssl\",\"username\":\"service@velixpay.com\",\"password\":\"Love748264\",\"from\":\"service@velixpay.com\",\"app_name\":\"vcccard\"}',NULL,'{\"method\":\"pusher\",\"instance_id\":\"255ae045-4995-4b74-9caf-b9b5101780df\",\"primary_key\":\"CDBB1D7FC33B562C63019647D3076998A14B97B251F651CB72B3934E49114200\"}',NULL,'{\"method\":\"pusher\",\"app_id\":\"1574360\",\"primary_key\":\"971ccaa6176db78407bf\",\"secret_key\":\" a30a6f1a61b97eb8225a\",\"cluster\":\"ap2\"}',NULL,NULL,NULL,'2024-09-02 23:57:50','2024-09-03 05:58:39','3.6.0');
/*!40000 ALTER TABLE `basic_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_categories`
--

DROP TABLE IF EXISTS `blog_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` bigint(20) unsigned NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_categories_admin_id_foreign` (`admin_id`),
  CONSTRAINT `blog_categories_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_categories`
--

LOCK TABLES `blog_categories` WRITE;
/*!40000 ALTER TABLE `blog_categories` DISABLE KEYS */;
INSERT INTO `blog_categories` VALUES (1,1,'Finance','finance',1,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(2,1,'Insurance','insurance',1,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(3,1,'Help','help',1,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(4,1,'Taxes','taxes',1,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(5,1,'Credit Card','credit-card',1,'2024-09-02 23:57:50','2024-09-02 23:57:50');
/*!40000 ALTER TABLE `blog_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` longtext COLLATE utf8mb4_unicode_ci,
  `details` longtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blogs_admin_id_foreign` (`admin_id`),
  KEY `blogs_category_id_foreign` (`category_id`),
  CONSTRAINT `blogs_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `blogs_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `blog_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` VALUES (1,1,5,'{\"language\":{\"en\":{\"name\":\"The Rise of Virtual Credit Cards: Transforming Online Payments\"},\"es\":{\"name\":\"El auge de las tarjetas de cr\\u00e9dito virtuales: transformando los pagos en l\\u00ednea\"},\"ar\":{\"name\":\"\\u0638\\u0647\\u0648\\u0631 \\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629: \\u062a\\u062d\\u0648\\u064a\\u0644 \\u0627\\u0644\\u0645\\u062f\\u0641\\u0648\\u0639\\u0627\\u062a \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a\"}}}','the-rise-of-virtual-credit-cards-transforming-online-payments','4ed4a526-d4e2-4132-82c5-5d846e044020.webp','[\"StripCard\",\"VirtualCard\",\"Appdevs\"]','{\"language\":{\"en\":{\"details\":\"<p>In today\\u2019s digital age, online payments have become an integral part of our lives. But with convenience comes the need for security. This blog explores the phenomenon of virtual credit cards, their growing popularity, and how they are revolutionizing online payments. We delve into the benefits of virtual credit cards, their unique features, and why they are considered the future of secure online transactions.<\\/p>\"},\"es\":{\"details\":\"<p>En la era digital actual, los pagos en l\\u00ednea se han convertido en una parte integral de nuestras vidas. Pero la comodidad conlleva la necesidad de seguridad. Este blog explora el fen\\u00f3meno de las tarjetas de cr\\u00e9dito virtuales, su creciente popularidad y c\\u00f3mo est\\u00e1n revolucionando los pagos en l\\u00ednea. Profundizamos en los beneficios de las tarjetas de cr\\u00e9dito virtuales, sus caracter\\u00edsticas \\u00fanicas y por qu\\u00e9 se consideran el futuro de las transacciones seguras en l\\u00ednea.<\\/p>\"},\"ar\":{\"details\":\"<p>\\u0641\\u064a \\u0627\\u0644\\u0639\\u0635\\u0631 \\u0627\\u0644\\u0631\\u0642\\u0645\\u064a \\u0627\\u0644\\u0630\\u064a \\u0646\\u0639\\u064a\\u0634\\u0647 \\u0627\\u0644\\u064a\\u0648\\u0645\\u060c \\u0623\\u0635\\u0628\\u062d\\u062a \\u0627\\u0644\\u0645\\u062f\\u0641\\u0648\\u0639\\u0627\\u062a \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a \\u062c\\u0632\\u0621\\u064b\\u0627 \\u0644\\u0627 \\u064a\\u062a\\u062c\\u0632\\u0623 \\u0645\\u0646 \\u062d\\u064a\\u0627\\u062a\\u0646\\u0627. \\u0648\\u0644\\u0643\\u0646 \\u0645\\u0639 \\u0627\\u0644\\u0631\\u0627\\u062d\\u0629 \\u062a\\u0623\\u062a\\u064a \\u0627\\u0644\\u062d\\u0627\\u062c\\u0629 \\u0625\\u0644\\u0649 \\u0627\\u0644\\u0623\\u0645\\u0646. \\u062a\\u0633\\u062a\\u0643\\u0634\\u0641 \\u0647\\u0630\\u0647 \\u0627\\u0644\\u0645\\u062f\\u0648\\u0646\\u0629 \\u0638\\u0627\\u0647\\u0631\\u0629 \\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629 \\u0648\\u0634\\u0639\\u0628\\u064a\\u062a\\u0647\\u0627 \\u0627\\u0644\\u0645\\u062a\\u0632\\u0627\\u064a\\u062f\\u0629 \\u0648\\u0643\\u064a\\u0641 \\u062a\\u064f\\u062d\\u062f\\u062b \\u062b\\u0648\\u0631\\u0629 \\u0641\\u064a \\u0645\\u062c\\u0627\\u0644 \\u0627\\u0644\\u062f\\u0641\\u0639 \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a. \\u0646\\u062d\\u0646 \\u0646\\u062a\\u0639\\u0645\\u0642 \\u0641\\u064a \\u0641\\u0648\\u0627\\u0626\\u062f \\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629\\u060c \\u0648\\u0645\\u064a\\u0632\\u0627\\u062a\\u0647\\u0627 \\u0627\\u0644\\u0641\\u0631\\u064a\\u062f\\u0629\\u060c \\u0648\\u0644\\u0645\\u0627\\u0630\\u0627 \\u062a\\u0639\\u062a\\u0628\\u0631 \\u0645\\u0633\\u062a\\u0642\\u0628\\u0644 \\u0627\\u0644\\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a \\u0627\\u0644\\u0622\\u0645\\u0646\\u0629 \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a.<\\/p>\"}}}',1,'2023-11-06 04:49:48','2023-11-06 04:49:48'),(2,1,5,'{\"language\":{\"en\":{\"name\":\"Entrepreneurial Success with Virtual Credit Card Services\"},\"es\":{\"name\":\"\\u00c9xito empresarial con servicios de tarjetas de cr\\u00e9dito virtuales\"},\"ar\":{\"name\":\"\\u0646\\u062c\\u0627\\u062d \\u0631\\u064a\\u0627\\u062f\\u0629 \\u0627\\u0644\\u0623\\u0639\\u0645\\u0627\\u0644 \\u0645\\u0639 \\u062e\\u062f\\u0645\\u0627\\u062a \\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629\"}}}','entrepreneurial-success-with-virtual-credit-card-services','56a5408b-0f2b-4eb0-9e56-004435a8170e.webp','[\"Money\",\"Online\",\"StripCard\",\"Payment\"]','{\"language\":{\"en\":{\"details\":\"<p>In today\\u2019s digital age, online payments have become an integral part of our lives. But with convenience comes the need for security. This blog explores the phenomenon of virtual credit cards, their growing popularity, and how they are revolutionizing online payments. We delve into the benefits of virtual credit cards, their unique features, and why they are considered the future of secure online transactions.<\\/p>\"},\"es\":{\"details\":\"<p>En la era digital actual, los pagos en l\\u00ednea se han convertido en una parte integral de nuestras vidas. Pero la comodidad conlleva la necesidad de seguridad. Este blog explora el fen\\u00f3meno de las tarjetas de cr\\u00e9dito virtuales, su creciente popularidad y c\\u00f3mo est\\u00e1n revolucionando los pagos en l\\u00ednea. Profundizamos en los beneficios de las tarjetas de cr\\u00e9dito virtuales, sus caracter\\u00edsticas \\u00fanicas y por qu\\u00e9 se consideran el futuro de las transacciones seguras en l\\u00ednea.<\\/p>\"},\"ar\":{\"details\":\"<p>\\u0641\\u064a \\u0627\\u0644\\u0639\\u0635\\u0631 \\u0627\\u0644\\u0631\\u0642\\u0645\\u064a \\u0627\\u0644\\u0630\\u064a \\u0646\\u0639\\u064a\\u0634\\u0647 \\u0627\\u0644\\u064a\\u0648\\u0645\\u060c \\u0623\\u0635\\u0628\\u062d\\u062a \\u0627\\u0644\\u0645\\u062f\\u0641\\u0648\\u0639\\u0627\\u062a \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a \\u062c\\u0632\\u0621\\u064b\\u0627 \\u0644\\u0627 \\u064a\\u062a\\u062c\\u0632\\u0623 \\u0645\\u0646 \\u062d\\u064a\\u0627\\u062a\\u0646\\u0627. \\u0648\\u0644\\u0643\\u0646 \\u0645\\u0639 \\u0627\\u0644\\u0631\\u0627\\u062d\\u0629 \\u062a\\u0623\\u062a\\u064a \\u0627\\u0644\\u062d\\u0627\\u062c\\u0629 \\u0625\\u0644\\u0649 \\u0627\\u0644\\u0623\\u0645\\u0646. \\u062a\\u0633\\u062a\\u0643\\u0634\\u0641 \\u0647\\u0630\\u0647 \\u0627\\u0644\\u0645\\u062f\\u0648\\u0646\\u0629 \\u0638\\u0627\\u0647\\u0631\\u0629 \\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629 \\u0648\\u0634\\u0639\\u0628\\u064a\\u062a\\u0647\\u0627 \\u0627\\u0644\\u0645\\u062a\\u0632\\u0627\\u064a\\u062f\\u0629 \\u0648\\u0643\\u064a\\u0641 \\u062a\\u064f\\u062d\\u062f\\u062b \\u062b\\u0648\\u0631\\u0629 \\u0641\\u064a \\u0645\\u062c\\u0627\\u0644 \\u0627\\u0644\\u062f\\u0641\\u0639 \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a. \\u0646\\u062d\\u0646 \\u0646\\u062a\\u0639\\u0645\\u0642 \\u0641\\u064a \\u0641\\u0648\\u0627\\u0626\\u062f \\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629\\u060c \\u0648\\u0645\\u064a\\u0632\\u0627\\u062a\\u0647\\u0627 \\u0627\\u0644\\u0641\\u0631\\u064a\\u062f\\u0629\\u060c \\u0648\\u0644\\u0645\\u0627\\u0630\\u0627 \\u062a\\u0639\\u062a\\u0628\\u0631 \\u0645\\u0633\\u062a\\u0642\\u0628\\u0644 \\u0627\\u0644\\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a \\u0627\\u0644\\u0622\\u0645\\u0646\\u0629 \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a.<\\/p>\"}}}',1,'2023-11-06 04:49:19','2023-11-06 04:49:19'),(3,1,2,'{\"language\":{\"en\":{\"name\":\"Entrepreneurial Success with Virtual Credit Card Services\"},\"es\":{\"name\":\"\\u00c9xito empresarial con servicios de tarjetas de cr\\u00e9dito virtuales\"},\"ar\":{\"name\":\"\\u0646\\u062c\\u0627\\u062d \\u0631\\u064a\\u0627\\u062f\\u0629 \\u0627\\u0644\\u0623\\u0639\\u0645\\u0627\\u0644 \\u0645\\u0639 \\u062e\\u062f\\u0645\\u0627\\u062a \\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629\"}}}','entrepreneurial-success-with-virtual-credit-card-services','5738b6fd-6f84-4fb9-b43f-4a60b2406301.webp','[\"StripCard\",\"Online Payment\",\"Virtual Card\"]','{\"language\":{\"en\":{\"details\":\"<p>Are you an entrepreneur looking to diversify your business and boost revenue? In this blog, we explore how offering virtual credit card services to your clients can be a game-changer. We discuss the opportunities, benefits, and strategies for entrepreneurs to leverage the virtual credit card trend and create a win-win scenario for their clients and their business.<\\/p>\"},\"es\":{\"details\":\"<p>\\u00bfEs usted un emprendedor que busca diversificar su negocio y aumentar los ingresos? En este blog, exploramos c\\u00f3mo ofrecer servicios de tarjetas de cr\\u00e9dito virtuales a sus clientes puede cambiar las reglas del juego. Discutimos las oportunidades, beneficios y estrategias para que los emprendedores aprovechen la tendencia de las tarjetas de cr\\u00e9dito virtuales y creen un escenario en el que todos ganan para sus clientes y sus negocios.<\\/p>\"},\"ar\":{\"details\":\"<p>\\u0647\\u0644 \\u0623\\u0646\\u062a \\u0631\\u0627\\u0626\\u062f \\u0623\\u0639\\u0645\\u0627\\u0644 \\u0648\\u062a\\u062a\\u0637\\u0644\\u0639 \\u0625\\u0644\\u0649 \\u062a\\u0646\\u0648\\u064a\\u0639 \\u0623\\u0639\\u0645\\u0627\\u0644\\u0643 \\u0648\\u0632\\u064a\\u0627\\u062f\\u0629 \\u0627\\u0644\\u0625\\u064a\\u0631\\u0627\\u062f\\u0627\\u062a\\u061f \\u0641\\u064a \\u0647\\u0630\\u0647 \\u0627\\u0644\\u0645\\u062f\\u0648\\u0646\\u0629\\u060c \\u0646\\u0633\\u062a\\u0643\\u0634\\u0641 \\u0643\\u064a\\u0641 \\u064a\\u0645\\u0643\\u0646 \\u0623\\u0646 \\u064a\\u0624\\u062f\\u064a \\u062a\\u0642\\u062f\\u064a\\u0645 \\u062e\\u062f\\u0645\\u0627\\u062a \\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629 \\u0644\\u0639\\u0645\\u0644\\u0627\\u0626\\u0643 \\u0625\\u0644\\u0649 \\u062a\\u063a\\u064a\\u064a\\u0631 \\u0642\\u0648\\u0627\\u0639\\u062f \\u0627\\u0644\\u0644\\u0639\\u0628\\u0629. \\u0646\\u0646\\u0627\\u0642\\u0634 \\u0627\\u0644\\u0641\\u0631\\u0635 \\u0648\\u0627\\u0644\\u0641\\u0648\\u0627\\u0626\\u062f \\u0648\\u0627\\u0644\\u0627\\u0633\\u062a\\u0631\\u0627\\u062a\\u064a\\u062c\\u064a\\u0627\\u062a \\u0644\\u0631\\u0648\\u0627\\u062f \\u0627\\u0644\\u0623\\u0639\\u0645\\u0627\\u0644 \\u0644\\u0644\\u0627\\u0633\\u062a\\u0641\\u0627\\u062f\\u0629 \\u0645\\u0646 \\u0627\\u062a\\u062c\\u0627\\u0647 \\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629 \\u0648\\u0625\\u0646\\u0634\\u0627\\u0621 \\u0633\\u064a\\u0646\\u0627\\u0631\\u064a\\u0648 \\u0645\\u0631\\u0628\\u062d \\u0644\\u0644\\u062c\\u0627\\u0646\\u0628\\u064a\\u0646 \\u0644\\u0639\\u0645\\u0644\\u0627\\u0626\\u0647\\u0645 \\u0648\\u0623\\u0639\\u0645\\u0627\\u0644\\u0647\\u0645.<\\/p>\"}}}',1,'2023-11-06 04:47:56','2023-11-06 04:47:56');
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_types`
--

DROP TABLE IF EXISTS `category_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) NOT NULL COMMENT '1=faq,2=event',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_types_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_types`
--

LOCK TABLES `category_types` WRITE;
/*!40000 ALTER TABLE `category_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coinbase_webhook_calls`
--

DROP TABLE IF EXISTS `coinbase_webhook_calls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coinbase_webhook_calls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci,
  `exception` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coinbase_webhook_calls`
--

LOCK TABLES `coinbase_webhook_calls` WRITE;
/*!40000 ALTER TABLE `coinbase_webhook_calls` DISABLE KEYS */;
/*!40000 ALTER TABLE `coinbase_webhook_calls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crypto_assets`
--

DROP TABLE IF EXISTS `crypto_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crypto_assets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_gateway_id` bigint(20) unsigned NOT NULL,
  `type` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chain` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coin` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `credentials` text COLLATE utf8mb4_unicode_ci,
  `assets` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crypto_assets_payment_gateway_id_foreign` (`payment_gateway_id`),
  CONSTRAINT `crypto_assets_payment_gateway_id_foreign` FOREIGN KEY (`payment_gateway_id`) REFERENCES `payment_gateways` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crypto_assets`
--

LOCK TABLES `crypto_assets` WRITE;
/*!40000 ALTER TABLE `crypto_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `crypto_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crypto_transactions`
--

DROP TABLE IF EXISTS `crypto_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crypto_transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `internal_trx_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Internal Transaction Type. EX: Add Money, Money Out',
  `internal_trx_ref_id` bigint(20) unsigned DEFAULT NULL COMMENT 'Internal Transaction Reference ID. EX: Transaction Table ID',
  `transaction_type` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sender_address` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receiver_address` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Can be positive and negative',
  `asset` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `block_number` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `txn_hash` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Transaction ID/Transaction Hash',
  `chain` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `callback_response` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NOT-USED',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crypto_transactions`
--

LOCK TABLES `crypto_transactions` WRITE;
/*!40000 ALTER TABLE `crypto_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `crypto_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currencies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` bigint(20) unsigned NOT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `symbol` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('CRYPTO','FIAT') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'FIAT',
  `flag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` decimal(28,8) NOT NULL DEFAULT '1.00000000',
  `sender` tinyint(1) NOT NULL DEFAULT '0',
  `receiver` tinyint(1) NOT NULL DEFAULT '0',
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `currencies_flag_unique` (`flag`),
  KEY `currencies_admin_id_foreign` (`admin_id`),
  KEY `currencies_country_index` (`country`),
  KEY `currencies_name_index` (`name`),
  KEY `currencies_code_index` (`code`),
  CONSTRAINT `currencies_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currencies`
--

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES (1,1,'United States','United States dollar','USD','$','FIAT','5d371250-25f9-449e-b17d-a46b71472681.webp',1.00000000,1,1,1,1,'2024-09-02 23:57:50','2024-09-02 23:57:50');
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exchange_rates`
--

DROP TABLE IF EXISTS `exchange_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange_rates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_symbol` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:Active,2:Inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange_rates`
--

LOCK TABLES `exchange_rates` WRITE;
/*!40000 ALTER TABLE `exchange_rates` DISABLE KEYS */;
INSERT INTO `exchange_rates` VALUES (1,'Afghanistan','93','Afghan afghani','AFN','؋',73.90411100,1,NULL,'2023-10-27 02:27:05'),(2,'Aland Islands','+358-18','Euro','EUR','€',0.95000000,1,NULL,'2023-10-27 02:27:05'),(3,'Albania','355','Albanian lek','ALL','Lek',100.16000000,1,NULL,'2023-10-27 02:27:05'),(4,'Algeria','213','Algerian dinar','DZD','دج',136.86000000,1,NULL,'2023-10-27 02:27:05'),(5,'United States','1','United States dollar','USD','$',1.00000000,1,NULL,NULL),(6,'American Samoa','+1-684','US Dollar','USD','$',2.80000000,1,NULL,'2023-10-27 02:27:05'),(7,'Andorra','376','Euro','EUR','€',0.95000000,1,NULL,'2023-10-27 02:27:05'),(8,'Angola','244','Angolan kwanza','AOA','Kz',828.50000000,1,NULL,'2023-10-27 02:27:05'),(9,'Anguilla','+1-264','East Caribbean dollar','XCD','$',2.70000000,1,NULL,'2023-10-27 02:27:05'),(10,'Antarctica','672','Antarctican dollar','AAD','$',3.67250000,1,NULL,'2023-10-27 02:27:05'),(11,'Antigua And Barbuda','+1-268','Eastern Caribbean dollar','XCD','$',2.70000000,1,NULL,'2023-10-27 02:27:05'),(12,'Argentina','54','Argentine peso','ARS','$',349.82000000,1,NULL,'2023-10-27 02:27:05'),(13,'Armenia','374','Armenian dram','AMD','֏',399.71000000,1,NULL,'2023-10-27 02:27:05'),(14,'Aruba','297','Aruban florin','AWG','ƒ',1.80000000,1,NULL,'2023-10-27 02:27:05'),(15,'Australia','61','Australian dollar','AUD','$',1.58000000,1,NULL,'2023-10-27 02:27:05'),(16,'Austria','43','Euro','EUR','€',0.95000000,1,NULL,'2023-10-27 02:27:05'),(17,'Azerbaijan','994','Azerbaijani manat','AZN','m',1.70000000,1,NULL,'2023-10-27 02:27:05'),(18,'Bahrain','973','Bahraini dinar','BHD','.د.ب',0.38000000,1,NULL,'2023-10-27 02:27:05'),(19,'Bangladesh','880','Bangladeshi taka','BDT','৳',110.04000000,1,NULL,'2023-10-27 02:27:05'),(20,'Barbados','+1-246','Barbadian dollar','BBD','Bds$',2.02000000,1,NULL,'2023-10-27 02:27:05'),(21,'Belarus','375','Belarusian ruble','BYN','Br',3.29000000,1,NULL,'2023-10-27 02:27:05'),(22,'Belgium','32','Euro','EUR','€',0.95000000,1,NULL,'2023-10-27 02:30:46'),(23,'Belize','501','Belize dollar','BZD','$',2.01000000,1,NULL,'2023-10-27 02:30:46'),(24,'Benin','229','West African CFA franc','XOF','CFA',621.30000000,1,NULL,'2023-10-27 02:30:46'),(25,'Bermuda','+1-441','Bermudian dollar','BMD','$',1.00000000,1,NULL,NULL),(26,'Bhutan','975','Bhutanese ngultrum','BTN','Nu.',83.06000000,1,NULL,'2023-10-27 02:30:46'),(27,'Bolivia','591','Bolivian boliviano','BOB','Bs.',6.90000000,1,NULL,'2023-10-27 02:30:46'),(28,'Bonaire, Sint Eustatius and Saba','599','United States dollar','USD','$',1.00000000,1,NULL,NULL),(29,'Bosnia and Herzegovina','387','Bosnia and Herzegovina convertible mark','BAM','KM',1.85000000,1,NULL,'2023-10-27 02:30:46'),(30,'Botswana','267','Botswana pula','BWP','P',1.00000000,1,NULL,NULL),(31,'Bouvet Island','0055','Norwegian Krone','NOK','kr',1.00000000,1,NULL,NULL),(32,'Brazil','55','Brazilian real','BRL','R$',1.00000000,1,NULL,NULL),(33,'British Indian Ocean Territory','246','United States dollar','USD','$',1.00000000,1,NULL,NULL),(34,'Brunei','673','Brunei dollar','BND','B$',1.00000000,1,NULL,NULL),(35,'Bulgaria','359','Bulgarian lev','BGN','Лв.',1.00000000,1,NULL,NULL),(36,'Burkina Faso','226','West African CFA franc','XOF','CFA',1.00000000,1,NULL,NULL),(37,'Burundi','257','Burundian franc','BIF','FBu',1.00000000,1,NULL,NULL),(38,'Cambodia','855','Cambodian riel','KHR','KHR',1.00000000,1,NULL,NULL),(39,'Cameroon','237','Central African CFA franc','XAF','FCFA',1.00000000,1,NULL,NULL),(40,'Canada','1','Canadian dollar','CAD','$',1.38000000,1,NULL,'2023-10-27 02:32:13'),(41,'Cape Verde','238','Cape Verdean escudo','CVE','$',1.00000000,1,NULL,NULL),(42,'Cayman Islands','+1-345','Cayman Islands dollar','KYD','$',1.00000000,1,NULL,NULL),(43,'Central African Republic','236','Central African CFA franc','XAF','FCFA',1.00000000,1,NULL,NULL),(44,'Chad','235','Central African CFA franc','XAF','FCFA',1.00000000,1,NULL,NULL),(45,'Chile','56','Chilean peso','CLP','$',1.00000000,1,NULL,NULL),(46,'China','86','Chinese yuan','CNY','¥',1.00000000,1,NULL,NULL),(47,'Christmas Island','61','Australian dollar','AUD','$',1.00000000,1,NULL,NULL),(48,'Cocos (Keeling) Islands','61','Australian dollar','AUD','$',1.00000000,1,NULL,NULL),(49,'Colombia','57','Colombian peso','COP','$',1.00000000,1,NULL,NULL),(50,'Comoros','269','Comorian franc','KMF','CF',1.00000000,1,NULL,NULL),(51,'Congo','242','Central African CFA franc','XAF','FC',1.00000000,1,NULL,NULL),(52,'Cook Islands','682','Cook Islands dollar','NZD','$',1.00000000,1,NULL,NULL),(53,'Costa Rica','506','Costa Rican colón','CRC','₡',1.00000000,1,NULL,NULL),(54,'Cote D\'Ivoire (Ivory Coast)','225','West African CFA franc','XOF','CFA',1.00000000,1,NULL,NULL),(55,'Croatia','385','Croatian kuna','HRK','kn',1.00000000,1,NULL,NULL),(56,'Cuba','53','Cuban peso','CUP','$',1.00000000,1,NULL,NULL),(57,'Curaçao','599','Netherlands Antillean guilder','ANG','ƒ',1.00000000,1,NULL,NULL),(58,'Cyprus','357','Euro','EUR','€',1.00000000,1,NULL,NULL),(59,'Czech Republic','420','Czech koruna','CZK','Kč',1.00000000,1,NULL,NULL),(60,'Democratic Republic of the Congo','243','Congolese Franc','CDF','FC',1.00000000,1,NULL,NULL),(61,'Denmark','45','Danish krone','DKK','Kr.',1.00000000,1,NULL,NULL),(62,'Djibouti','253','Djiboutian franc','DJF','Fdj',1.00000000,1,NULL,NULL),(63,'Dominica','+1-767','Eastern Caribbean dollar','XCD','$',1.00000000,1,NULL,NULL),(64,'Dominican Republic','+1-809 and 1-829','Dominican peso','DOP','$',1.00000000,1,NULL,NULL),(65,'East Timor','670','United States dollar','USD','$',1.00000000,1,NULL,NULL),(66,'Ecuador','593','United States dollar','USD','$',1.00000000,1,NULL,NULL),(67,'Egypt','20','Egyptian pound','EGP','ج.م',1.00000000,1,NULL,NULL),(68,'El Salvador','503','United States dollar','USD','$',1.00000000,1,NULL,NULL),(69,'Equatorial Guinea','240','Central African CFA franc','XAF','FCFA',1.00000000,1,NULL,NULL),(70,'Eritrea','291','Eritrean nakfa','ERN','Nfk',1.00000000,1,NULL,NULL),(71,'Estonia','372','Euro','EUR','€',1.00000000,1,NULL,NULL),(72,'Ethiopia','251','Ethiopian birr','ETB','Nkf',1.00000000,1,NULL,NULL),(73,'Falkland Islands','500','Falkland Islands pound','FKP','£',1.00000000,1,NULL,NULL),(74,'Faroe Islands','298','Danish krone','DKK','Kr.',1.00000000,1,NULL,NULL),(75,'Fiji Islands','679','Fijian dollar','FJD','FJ$',1.00000000,1,NULL,NULL),(76,'Finland','358','Euro','EUR','€',1.00000000,1,NULL,NULL),(77,'France','33','Euro','EUR','€',1.00000000,1,NULL,NULL),(78,'French Guiana','594','Euro','EUR','€',1.00000000,1,NULL,NULL),(79,'French Polynesia','689','CFP franc','XPF','₣',1.00000000,1,NULL,NULL),(80,'French Southern Territories','262','Euro','EUR','€',1.00000000,1,NULL,NULL),(81,'Gabon','241','Central African CFA franc','XAF','FCFA',1.00000000,1,NULL,NULL),(82,'Gambia The','220','Gambian dalasi','GMD','D',1.00000000,1,NULL,NULL),(83,'Georgia','995','Georgian lari','GEL','ლ',1.00000000,1,NULL,NULL),(84,'Germany','49','Euro','EUR','€',1.00000000,1,NULL,NULL),(85,'Ghana','233','Ghanaian cedi','GHS','GH₵',1.00000000,1,NULL,NULL),(86,'Gibraltar','350','Gibraltar pound','GIP','£',1.00000000,1,NULL,NULL),(87,'Greece','30','Euro','EUR','€',1.00000000,1,NULL,NULL),(88,'Greenland','299','Danish krone','DKK','Kr.',1.00000000,1,NULL,NULL),(89,'Grenada','+1-473','Eastern Caribbean dollar','XCD','$',1.00000000,1,NULL,NULL),(90,'Guadeloupe','590','Euro','EUR','€',1.00000000,1,NULL,NULL),(91,'Guam','+1-671','US Dollar','USD','$',1.00000000,1,NULL,NULL),(92,'Guatemala','502','Guatemalan quetzal','GTQ','Q',1.00000000,1,NULL,NULL),(93,'Guernsey and Alderney','+44-1481','British pound','GBP','£',1.00000000,1,NULL,NULL),(94,'Guinea','224','Guinean franc','GNF','FG',1.00000000,1,NULL,NULL),(95,'Guinea-Bissau','245','West African CFA franc','XOF','CFA',1.00000000,1,NULL,NULL),(96,'Guyana','592','Guyanese dollar','GYD','$',1.00000000,1,NULL,NULL),(97,'Haiti','509','Haitian gourde','HTG','G',1.00000000,1,NULL,NULL),(98,'Heard Island and McDonald Islands','672','Australian dollar','AUD','$',1.00000000,1,NULL,NULL),(99,'Honduras','504','Honduran lempira','HNL','L',1.00000000,1,NULL,NULL),(100,'Hong Kong S.A.R.','852','Hong Kong dollar','HKD','$',1.00000000,1,NULL,NULL),(101,'Hungary','36','Hungarian forint','HUF','Ft',1.00000000,1,NULL,NULL),(102,'Iceland','354','Icelandic króna','ISK','kr',1.00000000,1,NULL,NULL),(103,'India','91','Indian rupee','INR','₹',83.24000000,1,NULL,'2023-10-27 02:31:16'),(104,'Indonesia','62','Indonesian rupiah','IDR','Rp',1.00000000,1,NULL,NULL),(105,'Iran','98','Iranian rial','IRR','﷼',1.00000000,1,NULL,NULL),(106,'Iraq','964','Iraqi dinar','IQD','د.ع',1.00000000,1,NULL,NULL),(107,'Ireland','353','Euro','EUR','€',1.00000000,1,NULL,NULL),(108,'Israel','972','Israeli new shekel','ILS','₪',1.00000000,1,NULL,NULL),(109,'Italy','39','Euro','EUR','€',1.00000000,1,NULL,NULL),(110,'Jamaica','+1-876','Jamaican dollar','JMD','J$',1.00000000,1,NULL,NULL),(111,'Japan','81','Japanese yen','JPY','¥',1.00000000,1,NULL,NULL),(112,'Jersey','+44-1534','British pound','GBP','£',1.00000000,1,NULL,NULL),(113,'Jordan','962','Jordanian dinar','JOD','ا.د',1.00000000,1,NULL,NULL),(114,'Kazakhstan','7','Kazakhstani tenge','KZT','лв',1.00000000,1,NULL,NULL),(115,'Kenya','254','Kenyan shilling','KES','KSh',1.00000000,1,NULL,NULL),(116,'Kiribati','686','Australian dollar','AUD','$',1.00000000,1,NULL,NULL),(117,'Kosovo','383','Euro','EUR','€',1.00000000,1,NULL,NULL),(118,'Kuwait','965','Kuwaiti dinar','KWD','ك.د',1.00000000,1,NULL,NULL),(119,'Kyrgyzstan','996','Kyrgyzstani som','KGS','лв',1.00000000,1,NULL,NULL),(120,'Laos','856','Lao kip','LAK','₭',1.00000000,1,NULL,NULL),(121,'Latvia','371','Euro','EUR','€',1.00000000,1,NULL,NULL),(122,'Lebanon','961','Lebanese pound','LBP','£',1.00000000,1,NULL,NULL),(123,'Lesotho','266','Lesotho loti','LSL','L',1.00000000,1,NULL,NULL),(124,'Liberia','231','Liberian dollar','LRD','$',1.00000000,1,NULL,NULL),(125,'Libya','218','Libyan dinar','LYD','د.ل',1.00000000,1,NULL,NULL),(126,'Liechtenstein','423','Swiss franc','CHF','CHf',1.00000000,1,NULL,NULL),(127,'Lithuania','370','Euro','EUR','€',1.00000000,1,NULL,NULL),(128,'Luxembourg','352','Euro','EUR','€',1.00000000,1,NULL,NULL),(129,'Macau S.A.R.','853','Macanese pataca','MOP','$',1.00000000,1,NULL,NULL),(130,'Macedonia','389','Denar','MKD','ден',1.00000000,1,NULL,NULL),(131,'Madagascar','261','Malagasy ariary','MGA','Ar',1.00000000,1,NULL,NULL),(132,'Malawi','265','Malawian kwacha','MWK','MK',1.00000000,1,NULL,NULL),(133,'Malaysia','60','Malaysian ringgit','MYR','RM',1.00000000,1,NULL,NULL),(134,'Maldives','960','Maldivian rufiyaa','MVR','Rf',1.00000000,1,NULL,NULL),(135,'Mali','223','West African CFA franc','XOF','CFA',1.00000000,1,NULL,NULL),(136,'Malta','356','Euro','EUR','€',1.00000000,1,NULL,NULL),(137,'Man (Isle of)','+44-1624','British pound','GBP','£',1.00000000,1,NULL,NULL),(138,'Marshall Islands','692','United States dollar','USD','$',1.00000000,1,NULL,NULL),(139,'Martinique','596','Euro','EUR','€',1.00000000,1,NULL,NULL),(140,'Mauritania','222','Mauritanian ouguiya','MRO','MRU',1.00000000,1,NULL,NULL),(141,'Mauritius','230','Mauritian rupee','MUR','₨',1.00000000,1,NULL,NULL),(142,'Mayotte','262','Euro','EUR','€',1.00000000,1,NULL,NULL),(143,'Mexico','52','Mexican peso','MXN','$',1.00000000,1,NULL,NULL),(144,'Micronesia','691','United States dollar','USD','$',1.00000000,1,NULL,NULL),(145,'Moldova','373','Moldovan leu','MDL','L',1.00000000,1,NULL,NULL),(146,'Monaco','377','Euro','EUR','€',1.00000000,1,NULL,NULL),(147,'Mongolia','976','Mongolian tögrög','MNT','₮',1.00000000,1,NULL,NULL),(148,'Montenegro','382','Euro','EUR','€',1.00000000,1,NULL,NULL),(149,'Montserrat','+1-664','Eastern Caribbean dollar','XCD','$',1.00000000,1,NULL,NULL),(150,'Morocco','212','Moroccan dirham','MAD','DH',1.00000000,1,NULL,NULL),(151,'Mozambique','258','Mozambican metical','MZN','MT',1.00000000,1,NULL,NULL),(152,'Myanmar','95','Burmese kyat','MMK','K',1.00000000,1,NULL,NULL),(153,'Namibia','264','Namibian dollar','NAD','$',1.00000000,1,NULL,NULL),(154,'Nauru','674','Australian dollar','AUD','$',1.00000000,1,NULL,NULL),(155,'Nepal','977','Nepalese rupee','NPR','₨',132.91000000,1,NULL,'2023-10-27 02:34:33'),(156,'Netherlands','31','Euro','EUR','€',1.00000000,1,NULL,NULL),(157,'New Caledonia','687','CFP franc','XPF','₣',1.00000000,1,NULL,NULL),(158,'New Zealand','64','New Zealand dollar','NZD','$',1.00000000,1,NULL,NULL),(159,'Nicaragua','505','Nicaraguan córdoba','NIO','C$',1.00000000,1,NULL,NULL),(160,'Niger','227','West African CFA franc','XOF','CFA',1.00000000,1,NULL,NULL),(161,'Nigeria','234','Nigerian naira','NGN','₦',802.70000000,1,NULL,'2023-10-27 02:33:47'),(162,'Niue','683','New Zealand dollar','NZD','$',1.00000000,1,NULL,NULL),(163,'Norfolk Island','672','Australian dollar','AUD','$',1.00000000,1,NULL,NULL),(164,'North Korea','850','North Korean Won','KPW','₩',1.00000000,1,NULL,NULL),(165,'Northern Mariana Islands','+1-670','United States dollar','USD','$',1.00000000,1,NULL,NULL),(166,'Norway','47','Norwegian krone','NOK','kr',1.00000000,1,NULL,NULL),(167,'Oman','968','Omani rial','OMR','.ع.ر',1.00000000,1,NULL,NULL),(168,'Pakistan','92','Pakistani rupee','PKR','₨',279.59000000,1,NULL,'2023-10-27 02:34:08'),(169,'Palau','680','United States dollar','USD','$',1.00000000,1,NULL,NULL),(170,'Palestinian Territory Occupied','970','Israeli new shekel','ILS','₪',1.00000000,1,NULL,NULL),(171,'Panama','507','Panamanian balboa','PAB','B/.',1.00000000,1,NULL,NULL),(172,'Papua new Guinea','675','Papua New Guinean kina','PGK','K',1.00000000,1,NULL,NULL),(173,'Paraguay','595','Paraguayan guarani','PYG','₲',1.00000000,1,NULL,NULL),(174,'Peru','51','Peruvian sol','PEN','S/.',1.00000000,1,NULL,NULL),(175,'Philippines','63','Philippine peso','PHP','₱',1.00000000,1,NULL,NULL),(176,'Pitcairn Island','870','New Zealand dollar','NZD','$',1.00000000,1,NULL,NULL),(177,'Poland','48','Polish złoty','PLN','zł',1.00000000,1,NULL,NULL),(178,'Portugal','351','Euro','EUR','€',1.00000000,1,NULL,NULL),(179,'Puerto Rico','+1-787 and 1-939','United States dollar','USD','$',1.00000000,1,NULL,NULL),(180,'Qatar','974','Qatari riyal','QAR','ق.ر',1.00000000,1,NULL,NULL),(181,'Reunion','262','Euro','EUR','€',1.00000000,1,NULL,NULL),(182,'Romania','40','Romanian leu','RON','lei',1.00000000,1,NULL,NULL),(183,'Russia','7','Russian ruble','RUB','₽',1.00000000,1,NULL,NULL),(184,'Rwanda','250','Rwandan franc','RWF','FRw',1.00000000,1,NULL,NULL),(185,'Saint Helena','290','Saint Helena pound','SHP','£',1.00000000,1,NULL,NULL),(186,'Saint Kitts And Nevis','+1-869','Eastern Caribbean dollar','XCD','$',1.00000000,1,NULL,NULL),(187,'Saint Lucia','+1-758','Eastern Caribbean dollar','XCD','$',1.00000000,1,NULL,NULL),(188,'Saint Pierre and Miquelon','508','Euro','EUR','€',1.00000000,1,NULL,NULL),(189,'Saint Vincent And The Grenadines','+1-784','Eastern Caribbean dollar','XCD','$',1.00000000,1,NULL,NULL),(190,'Saint-Barthelemy','590','Euro','EUR','€',1.00000000,1,NULL,NULL),(191,'Saint-Martin (French part)','590','Euro','EUR','€',1.00000000,1,NULL,NULL),(192,'Samoa','685','Samoan tālā','WST','SAT',1.00000000,1,NULL,NULL),(193,'San Marino','378','Euro','EUR','€',1.00000000,1,NULL,NULL),(194,'Sao Tome and Principe','239','Dobra','STD','Db',1.00000000,1,NULL,NULL),(195,'Saudi Arabia','966','Saudi riyal','SAR','﷼',1.00000000,1,NULL,NULL),(196,'Senegal','221','West African CFA franc','XOF','CFA',1.00000000,1,NULL,NULL),(197,'Serbia','381','Serbian dinar','RSD','din',1.00000000,1,NULL,NULL),(198,'Seychelles','248','Seychellois rupee','SCR','SRe',1.00000000,1,NULL,NULL),(199,'Sierra Leone','232','Sierra Leonean leone','SLL','Le',1.00000000,1,NULL,NULL),(200,'Singapore','65','Singapore dollar','SGD','$',1.00000000,1,NULL,NULL),(201,'Sint Maarten (Dutch part)','1721','Netherlands Antillean guilder','ANG','ƒ',1.00000000,1,NULL,NULL),(202,'Slovakia','421','Euro','EUR','€',1.00000000,1,NULL,NULL),(203,'Slovenia','386','Euro','EUR','€',1.00000000,1,NULL,NULL),(204,'Solomon Islands','677','Solomon Islands dollar','SBD','Si$',1.00000000,1,NULL,NULL),(205,'Somalia','252','Somali shilling','SOS','Sh.so.',1.00000000,1,NULL,NULL),(206,'South Africa','27','South African rand','ZAR','R',1.00000000,1,NULL,NULL),(207,'South Georgia','500','British pound','GBP','£',1.00000000,1,NULL,NULL),(208,'South Korea','82','Won','KRW','₩',1.00000000,1,NULL,NULL),(209,'South Sudan','211','South Sudanese pound','SSP','£',1.00000000,1,NULL,NULL),(210,'Spain','34','Euro','EUR','€',1.00000000,1,NULL,NULL),(211,'Sri Lanka','94','Sri Lankan rupee','LKR','Rs',1.00000000,1,NULL,NULL),(212,'Sudan','249','Sudanese pound','SDG','.س.ج',1.00000000,1,NULL,NULL),(213,'Suriname','597','Surinamese dollar','SRD','$',1.00000000,1,NULL,NULL),(214,'Svalbard And Jan Mayen Islands','47','Norwegian Krone','NOK','kr',1.00000000,1,NULL,NULL),(215,'Swaziland','268','Lilangeni','SZL','E',1.00000000,1,NULL,NULL),(216,'Sweden','46','Swedish krona','SEK','kr',1.00000000,1,NULL,NULL),(217,'Switzerland','41','Swiss franc','CHF','CHf',1.00000000,1,NULL,NULL),(218,'Syria','963','Syrian pound','SYP','LS',1.00000000,1,NULL,NULL),(219,'Taiwan','886','New Taiwan dollar','TWD','$',1.00000000,1,NULL,NULL),(220,'Tajikistan','992','Tajikistani somoni','TJS','SM',1.00000000,1,NULL,NULL),(221,'Tanzania','255','Tanzanian shilling','TZS','TSh',2501.00000000,1,NULL,'2023-10-27 02:35:51'),(222,'Thailand','66','Thai baht','THB','฿',1.00000000,1,NULL,NULL),(223,'The Bahamas','+1-242','Bahamian dollar','BSD','B$',1.00000000,1,NULL,NULL),(224,'Togo','228','West African CFA franc','XOF','CFA',1.00000000,1,NULL,NULL),(225,'Tokelau','690','New Zealand dollar','NZD','$',1.00000000,1,NULL,NULL),(226,'Tonga','676','Tongan paʻanga','TOP','$',1.00000000,1,NULL,NULL),(227,'Trinidad And Tobago','+1-868','Trinidad and Tobago dollar','TTD','$',1.00000000,1,NULL,NULL),(228,'Tunisia','216','Tunisian dinar','TND','ت.د',1.00000000,1,NULL,NULL),(229,'Turkey','90','Turkish lira','TRY','₺',1.00000000,1,NULL,NULL),(230,'Turkmenistan','993','Turkmenistan manat','TMT','T',1.00000000,1,NULL,NULL),(231,'Turks And Caicos Islands','+1-649','United States dollar','USD','$',1.00000000,1,NULL,NULL),(232,'Tuvalu','688','Australian dollar','AUD','$',1.00000000,1,NULL,NULL),(233,'Uganda','256','Ugandan shilling','UGX','USh',1.00000000,1,NULL,NULL),(234,'Ukraine','380','Ukrainian hryvnia','UAH','₴',1.00000000,1,NULL,NULL),(235,'United Arab Emirates','971','United Arab Emirates dirham','AED','إ.د',1.00000000,1,NULL,NULL),(236,'United Kingdom','44','British pound','GBP','£',0.82000000,1,NULL,'2023-10-27 02:33:21'),(237,'United States Minor Outlying Islands','1','United States dollar','USD','$',1.00000000,1,NULL,NULL),(238,'Uruguay','598','Uruguayan peso','UYU','$',1.00000000,1,NULL,NULL),(239,'Uzbekistan','998','Uzbekistani soʻm','UZS','лв',1.00000000,1,NULL,NULL),(240,'Vanuatu','678','Vanuatu vatu','VUV','VT',1.00000000,1,NULL,NULL),(241,'Vatican City State (Holy See)','379','Euro','EUR','€',1.00000000,1,NULL,NULL),(242,'Venezuela','58','Bolívar','VEF','Bs',1.00000000,1,NULL,NULL),(243,'Vietnam','84','Vietnamese đồng','VND','₫',1.00000000,1,NULL,NULL),(244,'Virgin Islands (British)','+1-284','United States dollar','USD','$',1.00000000,1,NULL,NULL),(245,'Virgin Islands (US)','+1-340','United States dollar','USD','$',1.00000000,1,NULL,NULL),(246,'Wallis And Futuna Islands','681','CFP franc','XPF','₣',1.00000000,1,NULL,NULL),(247,'Western Sahara','212','Moroccan Dirham','MAD','MAD',1.00000000,1,NULL,NULL),(248,'Yemen','967','Yemeni rial','YER','﷼',1.00000000,1,NULL,NULL),(249,'Zambia','260','Zambian kwacha','ZMW','ZK',1.00000000,1,NULL,NULL),(250,'Zimbabwe','263','Zimbabwe Dollar','ZWL','$',1.00000000,1,NULL,NULL);
/*!40000 ALTER TABLE `exchange_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `extensions`
--

DROP TABLE IF EXISTS `extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `extensions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `script` text COLLATE utf8mb4_unicode_ci,
  `shortcode` text COLLATE utf8mb4_unicode_ci,
  `support_image` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=>enable, 2=>disable',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `extensions_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extensions`
--

LOCK TABLES `extensions` WRITE;
/*!40000 ALTER TABLE `extensions` DISABLE KEYS */;
INSERT INTO `extensions` VALUES (1,'Tawk','tawk-to','Go to your tawk to dashbaord. Click [setting icon] on top bar. Then click [Chat Widget] link from sidebar and follow the screenshot bellow. Copy property ID and paste it in Property ID field. Then copy widget ID and paste it in Widget ID field. Finally click on [Update] button and you are ready to go.','logo-tawk-to.png',NULL,'{\"property_id\":{\"title\":\"Property ID\",\"value\":\"\"},\"widget_id\":{\"title\":\"Widget ID\",\"value\":\"\"}}','instruction-tawk-to.png',1,'2024-09-02 23:57:50',NULL);
/*!40000 ALTER TABLE `extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq_sections`
--

DROP TABLE IF EXISTS `faq_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faq_sections` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `faq_sections_category_id_foreign` (`category_id`),
  CONSTRAINT `faq_sections_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `category_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq_sections`
--

LOCK TABLES `faq_sections` WRITE;
/*!40000 ALTER TABLE `faq_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `faq_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gift_card_apis`
--

DROP TABLE IF EXISTS `gift_card_apis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_card_apis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `provider` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Provider slug',
  `credentials` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'configuration credentials',
  `status` tinyint(4) NOT NULL COMMENT '1: Active, 2: Deactivate',
  `env` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sandbox' COMMENT 'environment',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gift_card_apis_provider_unique` (`provider`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift_card_apis`
--

LOCK TABLES `gift_card_apis` WRITE;
/*!40000 ALTER TABLE `gift_card_apis` DISABLE KEYS */;
INSERT INTO `gift_card_apis` VALUES (1,'RELOADLY','{\"client_id\":\"zdEpKtHis9zKyuQI89ctF7tfswm5HEyN\",\"secret_key\":\"weHaLOnFmO-OxuQ8nHGh91ilR8GIuE-Q4BTyFJOK5sH33mwPDw39BtYTwPgAtQv\",\"production_base_url\":\"https:\\/\\/giftcards.reloadly.com\",\"sandbox_base_url\":\"https:\\/\\/giftcards-sandbox.reloadly.com\"}',1,'sandbox','2024-04-06 21:16:17','2024-04-07 02:15:42');
/*!40000 ALTER TABLE `gift_card_apis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gift_cards`
--

DROP TABLE IF EXISTS `gift_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_cards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'should be USER, AGENT, Merchant',
  `user_id` bigint(20) unsigned NOT NULL,
  `user_wallet_id` bigint(20) unsigned NOT NULL,
  `recipient_currency_id` bigint(20) unsigned NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trx_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'internal TRX ID',
  `api_trx_id` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'TRX ID From API',
  `card_amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `card_total_amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `card_currency` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `card_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_wallet_currency` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exchange_rate` decimal(28,8) NOT NULL DEFAULT '1.00000000',
  `default_currency` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `percent_charge` decimal(28,8) NOT NULL DEFAULT '0.00000000' COMMENT 'charge percentage in default currency',
  `fixed_charge` decimal(28,8) NOT NULL DEFAULT '0.00000000' COMMENT 'charge fixed in default currency',
  `percent_charge_calc` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `fixed_charge_calc` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `total_charge` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `qty` int(11) NOT NULL,
  `unit_amount` decimal(28,8) NOT NULL DEFAULT '0.00000000' COMMENT 'Unit amount in user wallet currency',
  `conversion_amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `total_payable` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `api_currency` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'API owner account currency',
  `api_discount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `api_fee` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `api_sms_fee` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `api_total_fee` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `pre_order` tinyint(1) NOT NULL DEFAULT '0',
  `recipient_email` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recipient_country_iso2` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recipient_phone` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codes` text COLLATE utf8mb4_unicode_ci COMMENT 'Redeem Codes',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `details` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gift_cards_user_id_foreign` (`user_id`),
  CONSTRAINT `gift_cards_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift_cards`
--

LOCK TABLES `gift_cards` WRITE;
/*!40000 ALTER TABLE `gift_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `gift_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `last_edit_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `dir` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ltr',
  PRIMARY KEY (`id`),
  UNIQUE KEY `languages_name_unique` (`name`),
  UNIQUE KEY `languages_code_unique` (`code`),
  KEY `languages_last_edit_by_foreign` (`last_edit_by`),
  CONSTRAINT `languages_last_edit_by_foreign` FOREIGN KEY (`last_edit_by`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'English','en',0,1,'2024-09-02 23:57:50','2024-09-03 00:19:44','ltr'),(2,'Spanish','es',0,1,'2024-09-02 23:57:50',NULL,'ltr'),(3,'Arabic','ar',0,1,'2024-09-02 23:57:50',NULL,'rtl'),(4,'中文','cn',1,1,'2024-09-03 00:00:14','2024-09-03 06:03:17','ltr');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2022_12_11_061454_create_admins_table',1),(6,'2022_12_13_060252_create_transaction_settings_table',1),(7,'2022_12_14_103353_create_currencies_table',1),(8,'2022_12_17_104923_create_basic_settings_table',1),(9,'2022_12_18_093156_create_setup_seos_table',1),(10,'2022_12_19_072039_create_app_settings_table',1),(11,'2022_12_24_071800_create_site_sections_table',1),(12,'2022_12_24_110923_create_app_onboard_screens_table',1),(13,'2022_12_25_082623_create_payment_gateways_table',1),(14,'2022_12_26_060705_create_payment_gateway_currencies_table',1),(15,'2023_01_03_095454_create_extensions_table',1),(16,'2023_01_04_061756_create_setup_kycs_table',1),(17,'2023_01_07_053411_create_user_profiles_table',1),(18,'2023_01_08_133258_create_push_notification_records_table',1),(19,'2023_01_10_105235_create_user_password_resets_table',1),(20,'2023_01_10_115626_create_admin_login_logs_table',1),(21,'2023_01_11_121649_create_admin_roles_table',1),(22,'2023_01_11_122240_create_user_login_logs_table',1),(23,'2023_01_11_135434_update_admins_table',1),(24,'2023_01_12_052750_create_admin_role_permissions_table',1),(25,'2023_01_12_055605_create_exchange_rates_table',1),(26,'2023_01_12_055705_create_user_wallets_table',1),(27,'2023_01_14_093411_create_transactions_table',1),(28,'2023_01_14_154700_create_admin_role_has_permissions_table',1),(29,'2023_01_15_051638_create_admin_has_roles_table',1),(30,'2023_01_16_095331_create_temporary_datas_table',1),(31,'2023_01_18_043653_create_admin_notifications_table',1),(32,'2023_01_18_102653_create_languages_table',1),(33,'2023_01_19_060838_create_coinbase_webhook_calls_table',1),(34,'2023_01_28_075936_create_user_support_tickets_table',1),(35,'2023_01_28_081512_create_user_support_chats_table',1),(36,'2023_01_28_101246_create_user_support_ticket_attachments_table',1),(37,'2023_02_06_070418_create_user_mail_logs_table',1),(38,'2023_02_06_143558_create_user_authorizations_table',1),(39,'2023_02_07_154740_create_user_kyc_data_table',1),(40,'2023_02_09_083658_create_setup_pages_table',1),(41,'2023_02_23_072239_create_transaction_charges_table',1),(42,'2023_02_23_073232_create_transaction_devices_table',1),(43,'2023_03_02_054825_create_category_types_table',1),(44,'2023_03_02_115955_create_faq_sections_table',1),(45,'2023_03_11_054132_create_user_notifications_table',1),(46,'2023_03_15_060724_create_blog_categories_table',1),(47,'2023_03_15_112130_create_blogs_table',1),(48,'2023_03_23_152217_create_contacts_table',1),(49,'2023_03_30_102050_create_virtual_card_apis_table',1),(50,'2023_04_01_065330_create_virtual_cards_table',1),(51,'2023_06_21_133800_create_script_table',1),(52,'2023_07_19_174909_create_sudo_virtual_cards_table',1),(53,'2023_08_09_154956_add_user_table_update_column',1),(54,'2023_08_09_154956_add_user_table_update_column_for_strowallet',1),(55,'2023_08_09_154956_add_user_table_update_column_v1',1),(56,'2023_08_09_154956_add_user_table_update_column_v2',1),(57,'2023_08_09_154956_update_column_virtual_card_api_v1',1),(58,'2023_08_09_155439_add_basic_settings_table_update_column',1),(59,'2023_08_09_155834_blog_table_update_column',1),(60,'2023_08_09_155834_update_virtual_card_api_table_column',1),(61,'2023_08_26_222500_create_stripe_virtual_cards_table',1),(62,'2023_09_03_173051_add_column_on_languages_table',1),(63,'2023_09_13_155834_add_transaction_column',1),(64,'2023_09_16_130618_update_column_on_transactions_table',1),(65,'2023_10_30_163112_create_crypto_assets_table',1),(66,'2023_11_02_180143_create_crypto_transactions_table',1),(67,'2023_11_21_171439_create_strowallet_virtual_cards_table',1),(68,'2023_11_22_155834_update_virtual_card_for_default_system_table_column',1),(69,'2024_02_27_180149_update_strowallet_virtual_cards_table_column',1),(70,'2024_03_13_155834_update_transaction_column',1),(71,'2024_03_16_013002_create_gift_card_apis_table',1),(72,'2024_03_20_064600_create_gift_cards_table',1),(73,'2016_06_01_000001_create_oauth_auth_codes_table',2),(74,'2016_06_01_000002_create_oauth_access_tokens_table',2),(75,'2016_06_01_000003_create_oauth_refresh_tokens_table',2),(76,'2016_06_01_000004_create_oauth_clients_table',2),(77,'2016_06_01_000005_create_oauth_personal_access_clients_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_access_tokens`
--

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_auth_codes`
--

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_clients`
--

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
INSERT INTO `oauth_clients` VALUES (1,NULL,'StripCard Personal Access Client','qMA8H4j7Yzq7GJHnXylzfFxaiAtCo0BaFXiit4NM',NULL,'http://localhost',1,0,0,'2024-09-02 23:57:51','2024-09-02 23:57:51'),(2,NULL,'StripCard Password Grant Client','QsqZv9hJjqy6lTuR1MfV3cb3X9gpG51thku5EUBa','users','http://localhost',0,1,0,'2024-09-02 23:57:51','2024-09-02 23:57:51');
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_personal_access_clients`
--

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
INSERT INTO `oauth_personal_access_clients` VALUES (1,1,'2024-09-02 23:57:51','2024-09-02 23:57:51');
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_refresh_tokens`
--

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_gateway_currencies`
--

DROP TABLE IF EXISTS `payment_gateway_currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_gateway_currencies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_gateway_id` bigint(20) unsigned NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_symbol` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `min_limit` decimal(28,8) unsigned NOT NULL DEFAULT '0.00000000',
  `max_limit` decimal(28,8) unsigned NOT NULL DEFAULT '0.00000000',
  `percent_charge` decimal(28,8) unsigned NOT NULL DEFAULT '0.00000000',
  `fixed_charge` decimal(28,8) unsigned NOT NULL DEFAULT '0.00000000',
  `rate` decimal(28,8) unsigned NOT NULL DEFAULT '0.00000000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payment_gateway_currencies_alias_unique` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_gateway_currencies`
--

LOCK TABLES `payment_gateway_currencies` WRITE;
/*!40000 ALTER TABLE `payment_gateway_currencies` DISABLE KEYS */;
INSERT INTO `payment_gateway_currencies` VALUES (1,1,'Paypal USD','add-money-paypal-usd-automatic','USD','$',NULL,10.00000000,1000.00000000,1.00000000,2.00000000,1.00000000,'2023-08-29 05:14:57',NULL),(2,1,'Paypal AUD','add-money-paypal-aud-automatic','AUD','$',NULL,15.00000000,1500.00000000,1.00000000,2.00000000,1.55000000,'2023-08-29 05:14:57',NULL),(3,2,'Stripe USD','add-money-stripe-usd-automatic','USD','$',NULL,10.00000000,1000.00000000,1.00000000,2.00000000,1.00000000,'2023-08-29 05:14:57',NULL),(4,2,'Stripe AUD','add-money-stripe-aud-automatic','AUD','$',NULL,15.00000000,1500.00000000,1.00000000,2.00000000,1.55000000,'2023-08-29 05:14:57',NULL),(5,3,'AdPay (Manual) USD','adpay-manual-usd-manual','USD','$',NULL,10.00000000,1000.00000000,1.00000000,2.00000000,1.00000000,'2023-08-29 05:14:57','2023-10-03 06:36:51'),(6,4,'Bkash(Manual) BDT','bkashmanual-bdt-manual','BDT','৳',NULL,10.00000000,1000.00000000,1.00000000,2.00000000,109.13000000,'2023-08-29 05:14:57','2023-10-03 06:38:14'),(7,5,'Khalti(Manual) NPR','khaltimanual-npr-manual','NPR','रु',NULL,10.00000000,1000.00000000,1.00000000,2.00000000,132.05000000,'2023-08-29 05:14:57','2023-10-03 06:38:33'),(8,6,'JazzCash(Manual) PKR','jazzcashmanual-pkr-manual','PKR','रु',NULL,10.00000000,1000.00000000,1.00000000,2.00000000,303.16000000,'2023-08-29 05:14:57','2023-10-03 06:38:53'),(9,7,'EasyPaisa(Manual) PKR','easypaisamanual-pkr-manual','PKR','रु',NULL,10.00000000,1000.00000000,1.00000000,2.00000000,303.16000000,'2023-08-29 05:14:57','2023-10-03 06:39:05'),(10,8,'PhonePe(Manual) INR','phonepemanual-inr-manual','INR','₹',NULL,10.00000000,1000.00000000,1.00000000,2.00000000,82.67000000,'2023-08-29 05:14:57','2023-10-03 06:39:17'),(11,9,'UPI(Manual) INR','upimanual-inr-manual','INR','₹',NULL,10.00000000,1000.00000000,1.00000000,2.00000000,82.67000000,'2023-08-29 05:14:57','2023-10-03 06:39:30'),(12,10,'StripCard(Manual) USD','stripcardmanual-usd-money-out','USD','$',NULL,1.00000000,100.00000000,1.00000000,1.00000000,1.00000000,'2023-10-03 05:15:44','2023-10-03 05:34:59'),(13,11,'SSLCommerz BDT','add-money-sslcommerz-bdt-automatic','BDT','৳','06f617aa-a336-4382-987e-ae632929bed1.webp',100.00000000,50000.00000000,0.00000000,0.00000000,110.64000000,'2023-10-03 09:27:49','2023-10-03 09:29:55'),(14,12,'RazorPay INR','add-money-razorpay-inr-automatic','INR','₹','69b7df34-f1fb-4947-a6f5-e93b78648075.webp',100.00000000,100000.00000000,0.00000000,1.00000000,82.87000000,'2023-10-03 09:28:26','2023-10-03 09:28:26'),(15,13,'Flutterwave NGN','add-money-flutterwave-ngn-automatic','NGN','₦','17fb91c7-a29c-486a-ac5f-ca8bc69a1bfe.webp',1000.00000000,10000.00000000,1.00000000,0.00000000,464.00000000,'2023-10-03 09:29:06','2023-10-03 09:29:06'),(16,14,'QRPay USD','add-money-qrpay-usd-automatic','USD','$',NULL,1.00000000,100.00000000,0.00000000,1.00000000,1.00000000,'2023-11-06 07:23:33','2023-11-06 07:23:33'),(17,15,'CoinGate USDT','add-money-coingate-usdt-automatic','USDT','$',NULL,1.00000000,100.00000000,1.00000000,0.00000000,1.00000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(18,15,'CoinGate USD','add-money-coingate-usd-automatic','USD','$',NULL,1.00000000,100.00000000,1.00000000,0.00000000,1.00000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(19,16,'Tatum ETH','add-money-tatum-eth-automatic','ETH','ETH',NULL,0.00000000,1000.00000000,1.00000000,0.00000000,0.00044000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(20,16,'Tatum BTC','add-money-tatum-btc-automatic','BTC','BTC',NULL,0.00000000,1000.00000000,1.00000000,0.00000000,0.00002400,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(21,16,'Tatum SOL','add-money-tatum-sol-automatic','SOL','SOL',NULL,0.00000000,1000.00000000,1.00000000,0.00000000,3.76000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(22,17,'Perfect Money EUR','add-money-perfect-money-eur-automatic','EUR','€','a9f5fc3e-b53c-4fb8-9b9d-301c82b3158c.webp',1.00000000,1000.00000000,1.00000000,1.00000000,0.92000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(23,17,'Perfect Money USD','add-money-perfect-money-usd-automatic','USD','$','a9f5fc3e-b53c-4fb8-9b9d-301c82b3158c.webp',1.00000000,1000.00000000,1.00000000,1.00000000,1.00000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(24,12,'Razorpay GHS','add-money-razorpay-ghs-automatic','GHS',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,11.90000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(25,12,'Razorpay UZS','add-money-razorpay-uzs-automatic','UZS',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,12263.46000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(26,12,'Razorpay SAR','add-money-razorpay-sar-automatic','SAR',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,3.75000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(27,12,'Razorpay QAR','add-money-razorpay-qar-automatic','QAR',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,3.64000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(28,12,'Razorpay PKR','add-money-razorpay-pkr-automatic','PKR',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,286.50000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(29,12,'Razorpay PHP','add-money-razorpay-php-automatic','PHP',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,55.79000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(30,12,'Razorpay NPR','add-money-razorpay-npr-automatic','NPR',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,133.25000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(31,12,'Razorpay NGN','add-money-razorpay-ngn-automatic','NGN',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,780.00000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(32,12,'Razorpay MYR','add-money-razorpay-myr-automatic','MYR',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,4.69000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(33,12,'Razorpay MAD','add-money-razorpay-mad-automatic','MAD',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,10.21000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(34,12,'Razorpay LKR','add-money-razorpay-lkr-automatic','LKR',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,327.00000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(35,12,'Razorpay LBP','add-money-razorpay-lbp-automatic','LBP',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,15000.00000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(36,12,'Razorpay HKD','add-money-razorpay-hkd-automatic','HKD',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,7.81000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(37,12,'Razorpay EGP','add-money-razorpay-egp-automatic','EGP',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,30.85000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(38,12,'Razorpay BDT','add-money-razorpay-bdt-automatic','BDT',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,110.00000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(39,12,'Razorpay MXN','add-money-razorpay-mxn-automatic','MXN',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,17.57000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(40,12,'Razorpay NZD','add-money-razorpay-nzd-automatic','NZD',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,1.69000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(41,12,'Razorpay SEK','add-money-razorpay-sek-automatic','SEK',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,10.89000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(42,12,'Razorpay CNY','add-money-razorpay-cny-automatic','CNY',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,7.29000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(43,12,'Razorpay CAD','add-money-razorpay-cad-automatic','CAD',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,1.38000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(44,12,'Razorpay AUD','add-money-razorpay-aud-automatic','AUD',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,1.56000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(45,12,'Razorpay AED','add-money-razorpay-aed-automatic','AED',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,3.67000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(46,12,'Razorpay SGD','add-money-razorpay-sgd-automatic','SGD',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,1.36000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(47,12,'Razorpay GBP','add-money-razorpay-gbp-automatic','GBP',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,0.82000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(48,12,'Razorpay EUR','add-money-razorpay-eur-automatic','EUR',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,0.94000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(49,12,'Razorpay USD','add-money-razorpay-usd-automatic','USD',NULL,NULL,1.00000000,1000.00000000,2.00000000,1.00000000,1.00000000,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(50,18,'Pagadito USD','add-money-pagadito-usd-automatic','USD','$','seeder/pagadito.webp',1.00000000,1000.00000000,1.00000000,1.00000000,1.00000000,'2024-01-07 20:11:48','2024-01-07 20:12:21'),(51,18,'Pagadito HNL','add-money-pagadito-hnl-automatic','HNL',NULL,'seeder/pagadito.webp',0.00000000,0.00000000,0.00000000,0.00000000,24.62000000,'2024-01-07 20:11:48','2024-01-07 20:12:21'),(52,18,'Pagadito CRC','add-money-pagadito-crc-automatic','CRC',NULL,'seeder/pagadito.webp',1.00000000,1000.00000000,1.00000000,1.00000000,518.12000000,'2024-01-07 20:11:48','2024-01-07 20:12:21'),(53,18,'Pagadito DOP','add-money-pagadito-dop-automatic','DOP',NULL,'seeder/pagadito.webp',1.00000000,1000.00000000,1.00000000,1.00000000,58.02801200,'2024-01-07 20:11:48','2024-01-07 20:12:21'),(54,18,'Pagadito GTQ','add-money-pagadito-gtq-automatic','GTQ',NULL,'seeder/pagadito.webp',1.00000000,1000.00000000,1.00000000,1.00000000,7.81000000,'2024-01-07 20:11:48','2024-01-07 20:12:21'),(55,18,'Pagadito NIO','add-money-pagadito-nio-automatic','NIO',NULL,'seeder/pagadito.webp',1.00000000,1000.00000000,1.00000000,1.00000000,36.54000000,'2024-01-07 20:11:48','2024-01-07 20:12:21'),(56,18,'Pagadito PAB','add-money-pagadito-pab-automatic','PAB',NULL,'seeder/pagadito.webp',1.00000000,1000.00000000,1.00000000,1.00000000,1.00000000,'2024-01-07 20:11:48','2024-01-07 20:12:21'),(57,19,'epusdt USD','add-money-epusdt-usd-automatic','USD',NULL,NULL,1.00000000,500.00000000,0.00000000,0.00000000,1.00000000,'2024-09-03 00:14:56','2024-09-03 05:14:03');
/*!40000 ALTER TABLE `payment_gateway_currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_gateways`
--

DROP TABLE IF EXISTS `payment_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_gateways` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` int(10) unsigned NOT NULL,
  `type` enum('AUTOMATIC','MANUAL') COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alias` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credentials` text COLLATE utf8mb4_unicode_ci,
  `supported_currencies` text COLLATE utf8mb4_unicode_ci,
  `crypto` tinyint(1) NOT NULL DEFAULT '0',
  `desc` text COLLATE utf8mb4_unicode_ci,
  `input_fields` text COLLATE utf8mb4_unicode_ci,
  `env` enum('SANDBOX','PRODUCTION') COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Payment Gateway Environment (Ex: Production/Sandbox)',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `last_edit_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payment_gateways_code_unique` (`code`),
  KEY `payment_gateways_last_edit_by_foreign` (`last_edit_by`),
  CONSTRAINT `payment_gateways_last_edit_by_foreign` FOREIGN KEY (`last_edit_by`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_gateways`
--

LOCK TABLES `payment_gateways` WRITE;
/*!40000 ALTER TABLE `payment_gateways` DISABLE KEYS */;
INSERT INTO `payment_gateways` VALUES (1,'add-money',105,'AUTOMATIC','Paypal','Paypal Gateway','paypal','056c00f2-b983-499f-b53e-c27d66410866.webp','[{\"label\":\"Secret ID\",\"placeholder\":\"Enter Secret ID\",\"name\":\"secret-id\",\"value\":\"EOmsQW73ja4jFXUIpkeTuKj5qLcqiXRCPZMPx-2UNzNy729C5lzN8cYIdZRfHIx7xPVh9cyaeByefXJL\"},{\"label\":\"Client ID\",\"placeholder\":\"Enter Client ID\",\"name\":\"client-id\",\"value\":\"AZhkSGtOqSoGsixors18c5UDkmHD53TzNogt2ksVfxqDeu1RzqdjMClVv8VGarayaAH1exMK0JHMjE8v\"}]','[\"USD\",\"AUD\",\"CAD\",\"GBP\",\"SGD\",\"BRL\",\"EUR\",\"RUB\"]',0,NULL,NULL,NULL,1,1,'2023-08-29 05:14:57',NULL),(2,'add-money',106,'AUTOMATIC','Stripe','Stripe Gateway','stripe','25cc3ebb-13cb-4aa9-83df-77ebf1e8a785.webp','[{\"label\":\"Publishable Key\",\"placeholder\":\"Enter Publishable Key\",\"name\":\"publishable-key\",\"value\":\"pk_test_51NECrlJXLo7QTdMco2E4YxHSeoBnDvKmmi0CZl3hxjGgH1JwgcLVUF3ZR0yFraoRgT7hf0LtOReFADhShAZqTNuB003PnBSlGP\"},{\"label\":\"Secret Id\",\"placeholder\":\"Enter Secret ID\",\"name\":\"secret-id\",\"value\":\"sk_test_51NECrlJXLo7QTdMc2x7K5LaDuiS0MGNYHkO9dzzV0Y9XuWNZsXjECFsusjZEnqtxMIjCh3qtogc5sHHwL2oQ083900aFy1k7DE\"}]','[\"USD\",\"AUD\",\"AED\",\"BDT\",\"BGN\",\"CAD\",\"EGP\",\"EUR\",\"GBP\",\"INR\"]',0,NULL,NULL,NULL,1,1,'2023-08-29 05:14:57',NULL),(3,'add-money',110,'MANUAL','AdPay (Manual)','AdPay (Manual) Gateway','adpay-manual','6fe0ddbe-9c0c-4326-95bd-29ac7711b649.webp',NULL,'[\"USD\"]',0,'<p>This is the manual payment gateway for StripCard, Please follow the payment instruction and sumit required information.</p><p>.</p>','[{\"type\":\"file\",\"label\":\"Screenshoot\",\"name\":\"screenshoot\",\"required\":true,\"validation\":{\"max\":\"10\",\"mimes\":[\"jpg\",\"png\",\"webp\"],\"min\":0,\"options\":[],\"required\":true}},{\"type\":\"text\",\"label\":\"Transaction ID\",\"name\":\"transaction_id\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"0\",\"options\":[],\"required\":true}}]',NULL,1,1,'2023-08-29 05:14:57','2023-10-03 06:36:51'),(4,'add-money',115,'MANUAL','Bkash(Manual)','Bkash(Manual) Gateway','bkashmanual','7bee42e7-b1e9-4fe4-8db8-973b859babc7.webp',NULL,'[\"BDT\"]',0,'<p>This is the manual payment gateway for StripCard, Please follow the payment instruction and sumit required information.</p><p>.</p>','[{\"type\":\"text\",\"label\":\"Transaction ID\",\"name\":\"transaction_id\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"0\",\"options\":[],\"required\":true}},{\"type\":\"text\",\"label\":\"Phone Number\",\"name\":\"phone_number\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"0\",\"options\":[],\"required\":true}},{\"type\":\"file\",\"label\":\"Screenshoot\",\"name\":\"screenshoot\",\"required\":true,\"validation\":{\"max\":\"10\",\"mimes\":[\"jpg\",\"png\",\"webp\"],\"min\":0,\"options\":[],\"required\":true}}]',NULL,1,1,'2023-08-29 05:14:57','2023-10-03 06:38:14'),(5,'add-money',120,'MANUAL','Khalti(Manual)','Khalti(Manual) Gateway','khaltimanual','774e5db2-b461-4285-ad64-1caf6e5a0716.webp',NULL,'[\"NPR\"]',0,'<p>This is the manual payment gateway for StripCard, Please follow the payment instruction and sumit required information.</p><p>.</p>','[{\"type\":\"text\",\"label\":\"Transaction ID\",\"name\":\"transaction_id\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"0\",\"options\":[],\"required\":true}},{\"type\":\"text\",\"label\":\"Phone Number\",\"name\":\"phone_number\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"0\",\"options\":[],\"required\":true}},{\"type\":\"file\",\"label\":\"Screenshoot\",\"name\":\"screenshoot\",\"required\":true,\"validation\":{\"max\":\"10\",\"mimes\":[\"jpg\",\"png\",\"webp\"],\"min\":0,\"options\":[],\"required\":true}}]',NULL,1,1,'2023-08-29 05:14:57','2023-10-03 06:38:33'),(6,'add-money',125,'MANUAL','JazzCash(Manual)','JazzCash(Manual) Gateway','jazzcashmanual','c42ea4db-5067-4dda-92a1-4e00f20b5aaf.webp',NULL,'[\"PKR\"]',0,'<p>This is the manual payment gateway for StripCard, Please follow the payment instruction and sumit required information.</p><p>.</p>','[{\"type\":\"text\",\"label\":\"Transaction ID\",\"name\":\"transaction_id\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"0\",\"options\":[],\"required\":true}},{\"type\":\"text\",\"label\":\"Phone Number\",\"name\":\"phone_number\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"0\",\"options\":[],\"required\":true}},{\"type\":\"file\",\"label\":\"Screenshoot\",\"name\":\"screenshoot\",\"required\":true,\"validation\":{\"max\":\"10\",\"mimes\":[\"jpg\",\"png\",\"webp\"],\"min\":0,\"options\":[],\"required\":true}}]',NULL,1,1,'2023-08-29 05:14:57','2023-10-03 06:38:53'),(7,'add-money',130,'MANUAL','EasyPaisa(Manual)','EasyPaisa(Manual) Gateway','easypaisamanual','957603b7-d30a-4b70-b4d1-81d8c67ba751.webp',NULL,'[\"PKR\"]',0,'<p>This is the manual payment gateway for StripCard, Please follow the payment instruction and sumit required information.</p><p>.</p>','[{\"type\":\"text\",\"label\":\"Transaction ID\",\"name\":\"transaction_id\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"0\",\"options\":[],\"required\":true}},{\"type\":\"text\",\"label\":\"Phone Number\",\"name\":\"phone_number\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"0\",\"options\":[],\"required\":true}},{\"type\":\"file\",\"label\":\"Screenshoot\",\"name\":\"screenshoot\",\"required\":true,\"validation\":{\"max\":\"10\",\"mimes\":[\"jpg\",\"png\",\"webp\"],\"min\":0,\"options\":[],\"required\":true}}]',NULL,1,1,'2023-08-29 05:14:57','2023-10-03 06:39:05'),(8,'add-money',135,'MANUAL','PhonePe(Manual)','PhonePe(Manual) Gateway','phonepemanual','d6dcbd50-d68e-4535-ae2f-c35e3eb56872.webp',NULL,'[\"INR\"]',0,'<p>This is the manual payment gateway for StripCard, Please follow the payment instruction and sumit required information.</p><p>.</p>','[{\"type\":\"text\",\"label\":\"Transaction ID\",\"name\":\"transaction_id\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"0\",\"options\":[],\"required\":true}},{\"type\":\"text\",\"label\":\"Phone Number\",\"name\":\"phone_number\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"0\",\"options\":[],\"required\":true}},{\"type\":\"file\",\"label\":\"Screenshoot\",\"name\":\"screenshoot\",\"required\":true,\"validation\":{\"max\":\"10\",\"mimes\":[\"jpg\",\"png\",\"webp\"],\"min\":0,\"options\":[],\"required\":true}}]',NULL,1,1,'2023-08-29 05:14:57','2023-10-03 06:39:17'),(9,'add-money',140,'MANUAL','UPI(Manual)','UPI(Manual) Gateway','upimanual','80c9caa2-abc3-48c6-b239-778f10888632.webp',NULL,'[\"INR\"]',0,'<p>This is the manual payment gateway for StripCard, Please follow the payment instruction and sumit required information.</p><p>.</p>','[{\"type\":\"text\",\"label\":\"Transaction ID\",\"name\":\"transaction_id\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"0\",\"options\":[],\"required\":true}},{\"type\":\"text\",\"label\":\"Phone Number\",\"name\":\"phone_number\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"0\",\"options\":[],\"required\":true}},{\"type\":\"file\",\"label\":\"Screenshoot\",\"name\":\"screenshoot\",\"required\":true,\"validation\":{\"max\":\"10\",\"mimes\":[\"jpg\",\"png\",\"webp\"],\"min\":0,\"options\":[],\"required\":true}}]',NULL,1,1,'2023-08-29 05:14:57','2023-10-03 06:39:30'),(10,'money-out',145,'MANUAL','StripCard(Manual)','StripCard(Manual) Gateway','stripcardmanual','274b95fc-258a-445e-ad96-6d91783e6d9b.webp',NULL,'[\"USD\"]',0,'<p>This is the manual withdraw gateway for StripCard, Please follow the withdraw instruction and sumit required information.</p>','[{\"type\":\"text\",\"label\":\"Email\",\"name\":\"email\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"5\",\"options\":[],\"required\":true}},{\"type\":\"text\",\"label\":\"Card Number\",\"name\":\"card_number\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"16\",\"options\":[],\"required\":true}},{\"type\":\"text\",\"label\":\"Card Expiry\",\"name\":\"card_expiry\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"4\",\"options\":[],\"required\":true}},{\"type\":\"text\",\"label\":\"CVC\",\"name\":\"cvc\",\"required\":true,\"validation\":{\"max\":\"30\",\"mimes\":[],\"min\":\"3\",\"options\":[],\"required\":true}}]',NULL,1,1,NULL,'2023-10-03 05:34:59'),(11,'add-money',210,'AUTOMATIC','SSLCommerz','SSLCommerz Payment Gateway For Add Money','sslcommerz','f4fe90e9-9b25-48b8-b3f5-9847cfbc6da7.webp','[{\"label\":\"Store Id\",\"placeholder\":\"Enter Store Id\",\"name\":\"store-id\",\"value\":\"appde6513b3970d62c\"},{\"label\":\"Store Password\",\"placeholder\":\"Enter Store Password\",\"name\":\"store-password\",\"value\":\"appde6513b3970d62c@ssl\"},{\"label\":\"Sandbox Url\",\"placeholder\":\"Enter Sandbox Url\",\"name\":\"sandbox-url\",\"value\":\"https:\\/\\/sandbox.sslcommerz.com\"},{\"label\":\"Live Url\",\"placeholder\":\"Enter Live Url\",\"name\":\"live-url\",\"value\":\"https:\\/\\/securepay.sslcommerz.com\"}]','[\"BDT\",\"EUR\",\"GBP\",\"AUD\",\"USD\",\"CAD\"]',0,NULL,NULL,'SANDBOX',1,1,'2023-09-27 08:11:26','2023-09-27 08:11:53'),(12,'add-money',200,'AUTOMATIC','RazorPay','Razor Pay Payment Gateway','razorpay','7f46e145-774e-41bf-9170-243605a5d4d0.webp','[{\"label\":\"Key ID\",\"placeholder\":\"Enter Key ID\",\"name\":\"key-id\",\"value\":\"rzp_test_voV4gKUbSxoQez\"},{\"label\":\"Secret Key\",\"placeholder\":\"Enter Secret Key\",\"name\":\"secret-key\",\"value\":\"cJltc1jy6evA4Vvh9lTO7SWr\"}]','[\"USD\",\"EUR\",\"GBP\",\"SGD\",\"AED\",\"AUD\",\"CAD\",\"CNY\",\"SEK\",\"NZD\",\"MXN\",\"BDT\",\"EGP\",\"HKD\",\"INR\",\"LBP\",\"LKR\",\"MAD\",\"MYR\",\"NGN\",\"NPR\",\"PHP\",\"PKR\",\"QAR\",\"SAR\",\"UZS\",\"GHS\"]',0,NULL,NULL,'SANDBOX',1,1,'2023-08-23 05:21:55','2023-08-23 05:23:20'),(13,'add-money',142,'AUTOMATIC','Flutterwave','Flutterwave Payement Gateway','flutterwave','137701d0-4e12-4a21-bc63-cda5454c2476.webp','[{\"label\":\"Encryption key\",\"placeholder\":\"Enter Encryption key\",\"name\":\"encryption-key\",\"value\":\"FLWSECK_TEST27bee2235efd\"},{\"label\":\"Secret key\",\"placeholder\":\"Enter Secret key\",\"name\":\"secret-key\",\"value\":\"FLWSECK_TEST-da35e3dbd28be1e7dc5d5f3519e2ebef-X\"},{\"label\":\"Public key\",\"placeholder\":\"Enter Public key\",\"name\":\"public-key\",\"value\":\"FLWPUBK_TEST-e0bc02a00395b938a4a2bed65e1bc94f-X\"}]','[\"AED\", \"ARS\", \"AUD\", \"CAD\", \"CHF\", \"CZK\", \"ETB\", \"EUR\", \"GBP\", \"GHS\", \"ILS\", \"INR\", \"JPY\", \"KES\", \"MAD\", \"MUR\", \"MYR\", \"NGN\", \"NOK\", \"NZD\", \"PEN\", \"PLN\", \"RUB\", \"RWF\", \"SAR\", \"SEK\", \"SGD\", \"SLL\", \"TZS\", \"UGX\", \"USD\", \"XAF\", \"XOF\", \"ZAR\", \"ZMK\", \"ZMW\", \"MWK\"]',0,NULL,NULL,NULL,1,1,'2023-05-25 03:40:27','2023-05-30 10:42:59'),(14,'add-money',215,'AUTOMATIC','QRPay','QRPay Payment Gateway For Add Money','qrpay','7bcdead3-6b43-46db-8433-f15d5755827c.webp','[{\"label\":\"Live Base Url\",\"placeholder\":\"Enter Live Base Url\",\"name\":\"live-base-url\",\"value\":\"https:\\/\\/envato.appdevs.net\\/qrpay\\/pay\\/api\\/v1\"},{\"label\":\"Sendbox Base Url\",\"placeholder\":\"Enter Sendbox Base Url\",\"name\":\"sendbox-base-url\",\"value\":\"https:\\/\\/envato.appdevs.net\\/qrpay\\/pay\\/sandbox\\/api\\/v1\"},{\"label\":\"Client Secret\",\"placeholder\":\"Enter Client Secret\",\"name\":\"client-secret\",\"value\":\"oZouVmqHCbyg6ad7iMnrwq3d8wy9Kr4bo6VpQnsX6zAOoEs4oxHPjttpun36JhGxDl7AUMz3ShUqVyPmxh4oPk3TQmDF7YvHN5M3\"},{\"label\":\"Client Id\",\"placeholder\":\"Enter Client Id\",\"name\":\"client-id\",\"value\":\"tRCDXCuztQzRYThPwlh1KXAYm4bG3rwWjbxM2R63kTefrGD2B9jNn6JnarDf7ycxdzfnaroxcyr5cnduY6AqpulRSebwHwRmGerA\"}]','[\"USD\"]',0,NULL,NULL,'SANDBOX',1,1,'2023-11-06 07:21:19','2023-11-06 07:22:28'),(15,'add-money',220,'AUTOMATIC','CoinGate','Crypto Payment gateway (CoinGate)','coingate','7e1f09b8-7c58-44bb-9de5-133eaffc10eb.webp','[{\"label\":\"Sandbox URL\",\"placeholder\":\"Enter Sandbox URL\",\"name\":\"sandbox-url\",\"value\":\"https:\\/\\/api-sandbox.coingate.com\\/v2\"},{\"label\":\"Sandbox App Token\",\"placeholder\":\"Enter Sandbox App Token\",\"name\":\"sandbox-app-token\",\"value\":\"XJW4RyhT8F-xssX2PvaHMWJjYe5nsbsrbb2Uqy4m\"},{\"label\":\"Production URL\",\"placeholder\":\"Enter Production URL\",\"name\":\"production-url\",\"value\":\"https:\\/\\/api.coingate.com\\/v2\"},{\"label\":\"Production App Token\",\"placeholder\":\"Enter Production App Token\",\"name\":\"production-app-token\",\"value\":null}]','[\"USD\",\"BTC\",\"LTC\",\"ETH\",\"BCH\",\"TRX\",\"ETC\",\"DOGE\",\"BTG\",\"BNB\",\"TUSD\",\"USDT\",\"BSV\",\"MATIC\",\"BUSD\",\"SOL\",\"WBTC\",\"RVN\",\"BCD\",\"ATOM\",\"BTTC\",\"EURT\"]',0,NULL,NULL,'SANDBOX',1,1,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(16,'add-money',225,'AUTOMATIC','Tatum','Tatum Gateway','tatum','b6d31ae3-6b79-453a-a699-1c741b6cc0fe.webp','[{\"label\":\"Testnet\",\"placeholder\":\"Enter Testnet\",\"name\":\"test-net\",\"value\":\"t-657aafddb117a3001c86eda4-37941d61197f4aa6bf416aff\"},{\"label\":\"Mainnet\",\"placeholder\":\"Enter Mainnet\",\"name\":\"main-net\",\"value\":\"t-657aafddb117a3001c86eda4-53dede7263974bb4a63d6e0e\"}]','[\"BTC\",\"ETH\",\"SOL\"]',1,NULL,NULL,'SANDBOX',1,1,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(17,'add-money',230,'AUTOMATIC','Perfect Money','Perfect Money Gateway','perfect-money','a9f5fc3e-b53c-4fb8-9b9d-301c82b3158c.webp','[{\"label\":\"Alternate Passphrase\",\"placeholder\":\"Enter Alternate Passphrase\",\"name\":\"alternate-passphrase\",\"value\":\"t0d2nbK2ZA92fRTnIFsMTWsHT\"},{\"label\":\"EUR Account\",\"placeholder\":\"Enter EUR Account\",\"name\":\"eur-account\",\"value\":\"E39620511\"},{\"label\":\"USD Account\",\"placeholder\":\"Enter USD Account\",\"name\":\"usd-account\",\"value\":\"U39903302\"}]','[\"USD\",\"EUR\"]',0,NULL,NULL,'SANDBOX',1,1,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(18,'add-money',245,'AUTOMATIC','Pagadito','Pagadito Payment gateway','pagadito','seeder/pagadito.webp','[{\"label\":\"UID\",\"placeholder\":\"Enter UID\",\"name\":\"uid\",\"value\":\"b73eb3fa1dc8bea4b4363322c906a8fd\"},{\"label\":\"WSK\",\"placeholder\":\"Enter WSK\",\"name\":\"wsk\",\"value\":\"dc843ff5865bac2858ad8f23af081256\"},{\"label\":\"base_url\",\"placeholder\":\"Enter base_url\",\"name\":\"base_url\",\"value\":\"https:\\/\\/sandbox.pagadito.com\"}]','[\"USD\",\"HNL\",\"CRC\",\"DOP\",\"GTQ\",\"NIO\",\"PAB\"]',0,NULL,NULL,'SANDBOX',1,1,'2024-09-02 23:57:50','2024-09-02 23:57:50'),(19,'add-money',250,'AUTOMATIC','epusdt','epusdt','epusdt',NULL,'[{\"label\":\"payment_url\",\"placeholder\":\"Enter payment_url\",\"name\":\"payment-url\",\"value\":\"http:\\/\\/127.0.0.1:8000\\/api\\/v1\\/order\\/create-transaction\"},{\"label\":\"merchant_key\",\"placeholder\":\"Enter merchant_key\",\"name\":\"merchant-key\",\"value\":\"epusdt_password_virtualcard_api\"}]','[\"USD\"]',0,NULL,NULL,'PRODUCTION',1,1,'2024-09-03 00:14:23','2024-09-03 05:14:03');
/*!40000 ALTER TABLE `payment_gateways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `push_notification_records`
--

DROP TABLE IF EXISTS `push_notification_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_notification_records` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_ids` text COLLATE utf8mb4_unicode_ci,
  `device_ids` text COLLATE utf8mb4_unicode_ci,
  `method` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `response` text COLLATE utf8mb4_unicode_ci,
  `message` text COLLATE utf8mb4_unicode_ci,
  `send_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `push_notification_records_send_by_foreign` (`send_by`),
  CONSTRAINT `push_notification_records_send_by_foreign` FOREIGN KEY (`send_by`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_notification_records`
--

LOCK TABLES `push_notification_records` WRITE;
/*!40000 ALTER TABLE `push_notification_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_notification_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `script`
--

DROP TABLE IF EXISTS `script`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `script` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `signature` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `script`
--

LOCK TABLES `script` WRITE;
/*!40000 ALTER TABLE `script` DISABLE KEYS */;
INSERT INTO `script` VALUES (1,'velixpay.com','eyJfdG9rZW4iOiJ5NjVvZ1BlTjlTV0U4cFdQSWFZdXZlUkF1YUs2UGpNTUtlTGNUZXByIiwidXNlcm5hbWUiOiJzamYxMTBAZ21haWwuY29tIiwiY29kZSI6IjI1U0dBQiIsImNsaWVudCI6eyJjbGllbnQiOiJodHRwczpcL1wvdmVsaXhwYXkuY29tIn0sImFwcF9uYW1lIjoidmNjY2FyZCIsImhvc3QiOiJsb2NhbGhvc3QiLCJkYl9uYW1lIjoiY3Z2Y2FyZCIsImRiX3VzZXIiOiJjdnZjYXJkIiwiZGJfdXNlcl9wYXNzd29yZCI6InN1bmppYWZ1IiwiZW1haWwiOiJzamYxMTBAZ21haWwuY29tIiwiZl9uYW1lIjoibGFyaWVuYSIsImxfbmFtZSI6InN1biIsInBhc3N3b3JkIjoiTG92ZTc0ODI2NCJ9',NULL,NULL);
/*!40000 ALTER TABLE `script` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setup_kycs`
--

DROP TABLE IF EXISTS `setup_kycs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setup_kycs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fields` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `last_edit_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setup_kycs_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setup_kycs`
--

LOCK TABLES `setup_kycs` WRITE;
/*!40000 ALTER TABLE `setup_kycs` DISABLE KEYS */;
INSERT INTO `setup_kycs` VALUES (1,'user','USER','[{\"type\":\"select\",\"label\":\"ID Type\",\"name\":\"id_type\",\"required\":true,\"validation\":{\"max\":0,\"min\":0,\"mimes\":[],\"options\":[\"NID\",\" Driving License\",\" Passport\"],\"required\":true}},{\"type\":\"file\",\"label\":\"Back\",\"name\":\"back\",\"required\":true,\"validation\":{\"max\":\"2\",\"mimes\":[\"jpg\",\" png\",\" webp\",\" jpeg\"],\"min\":0,\"options\":[],\"required\":true}},{\"type\":\"file\",\"label\":\"Front\",\"name\":\"front\",\"required\":true,\"validation\":{\"max\":\"2\",\"mimes\":[\"jpg\",\" png\",\" webp\",\" jpeg\"],\"min\":0,\"options\":[],\"required\":true}}]',1,1,'2024-09-02 23:57:50','2024-09-02 23:57:50');
/*!40000 ALTER TABLE `setup_kycs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setup_pages`
--

DROP TABLE IF EXISTS `setup_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setup_pages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` text COLLATE utf8mb4_unicode_ci,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` longtext COLLATE utf8mb4_unicode_ci,
  `last_edit_by` bigint(20) unsigned DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setup_pages_slug_unique` (`slug`),
  KEY `setup_pages_last_edit_by_foreign` (`last_edit_by`),
  CONSTRAINT `setup_pages_last_edit_by_foreign` FOREIGN KEY (`last_edit_by`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setup_pages`
--

LOCK TABLES `setup_pages` WRITE;
/*!40000 ALTER TABLE `setup_pages` DISABLE KEYS */;
INSERT INTO `setup_pages` VALUES (1,'setup-page','home','{\"title\":\"Home\"}','/',NULL,1,1,'2024-09-02 23:57:50',NULL),(2,'setup-page','about','{\"title\":\"About\"}','/about',NULL,1,1,'2024-09-02 23:57:50',NULL),(3,'setup-page','services','{\"title\":\"Services\"}','/services',NULL,1,1,'2024-09-02 23:57:50',NULL),(4,'setup-page','announcement','{\"title\":\"Announcement\"}','announcement',NULL,1,0,'2024-09-02 23:57:50','2024-09-03 06:03:39'),(5,'setup-page','contact','{\"title\":\"Contact\"}','/contact',NULL,1,1,'2024-09-02 23:57:50',NULL),(6,'useful-links','privacy-policy','{\"language\":{\"en\":{\"title\":\"Privacy Policy\"},\"es\":{\"title\":\"pol\\u00edtica de privacidad\"}}}',NULL,'{\"language\":{\"en\":{\"details\":\"<h3 style=\\\"margin-left:0px;\\\"><strong>What information do we collect?<\\/strong><\\/h3><p style=\\\"margin-left:0px;\\\">We gather data from you when you register on our site, submit a request, buy any services, react to an overview, or round out a structure. At the point when requesting any assistance or enrolling on our site, as suitable, you might be approached to enter your: name, email address, or telephone number. You may, nonetheless, visit our site anonymously.<\\/p><h3 style=\\\"margin-left:0px;\\\"><strong>How do we protect your information?<\\/strong><\\/h3><p style=\\\"margin-left:0px;\\\">All provided delicate\\/credit data is sent through Stripe.<br>After an exchange, your private data (credit cards, social security numbers, financials, and so on) won be put away on our workers.<\\/p><h3 style=\\\"margin-left:0px;\\\"><strong>Do we disclose any information to outside parties?<\\/strong><\\/h3><p style=\\\"margin-left:0px;\\\">We don sell, exchange, or in any case move to outside gatherings by and by recognizable data. This does exclude confided in outsiders who help us in working our site, leading our business, or adjusting you, since those gatherings consent to keep this data private. We may likewise deliver your data when we accept discharge is suitable to follow the law, implement our site strategies, or ensure our own or others rights, property, or wellbeing.<\\/p><h3 style=\\\"margin-left:0px;\\\"><strong>Childrens Online Privacy Protection Act Compliance<\\/strong><\\/h3><p style=\\\"margin-left:0px;\\\">We are consistent with the prerequisites of COPPA (Childrens Online Privacy Protection Act), we don gather any data from anybody under 13 years old. Our site, items, and administrations are completely coordinated to individuals who are in any event 13 years of age or more established.<\\/p><h3 style=\\\"margin-left:0px;\\\"><strong>Changes to our Privacy Policy<\\/strong><\\/h3><p style=\\\"margin-left:0px;\\\">If we decide to change our privacy policy, we will post those changes on this page.<\\/p><h3 style=\\\"margin-left:0px;\\\"><strong>How long we retain your information?<\\/strong><\\/h3><p style=\\\"margin-left:0px;\\\">At the point when you register for our site, we cycle and keep your information we have about you however long you don not erase the record or withdraw yourself (subject to laws and guidelines).<\\/p><h2 style=\\\"margin-left:0px;text-align:center;\\\">&nbsp;<\\/h2>\"},\"es\":{\"details\":\"<p>\\u00bfQu\\u00e9 informaci\\u00f3n recopilamos?<\\/p><p>Recopilamos sus datos cuando se registra en nuestro sitio, env\\u00eda una solicitud, compra cualquier servicio, reacciona a una descripci\\u00f3n general o completa una estructura. Cuando solicite asistencia o se registre en nuestro sitio, seg\\u00fan corresponda, se le pedir\\u00e1 que ingrese su: nombre, direcci\\u00f3n de correo electr\\u00f3nico o n\\u00famero de tel\\u00e9fono. No obstante, puede visitar nuestro sitio de forma an\\u00f3nima.<\\/p><p>\\u00bfC\\u00f3mo protegemos tu informaci\\u00f3n?<\\/p><p>Todos los datos delicados\\/de cr\\u00e9dito proporcionados se env\\u00edan a trav\\u00e9s de Stripe.<br>Despu\\u00e9s de un intercambio, sus datos privados (tarjetas de cr\\u00e9dito, n\\u00fameros de seguridad social, datos financieros, etc.) se guardar\\u00e1n en nuestros trabajadores.<\\/p><p>\\u00bfRevelamos informaci\\u00f3n a terceros?<\\/p><p>No vendemos, intercambiamos o, en cualquier caso, nos trasladamos a reuniones externas por y por datos reconocibles. Esto excluye a personas ajenas a la confianza que nos ayudan a trabajar en nuestro sitio, liderar nuestro negocio o ajustarlo, ya que esos grupos aceptan mantener estos datos privados. Tambi\\u00e9n podemos entregar sus datos cuando aceptemos que la descarga es adecuada para cumplir con la ley, implementar las estrategias de nuestro sitio o garantizar nuestros derechos, propiedad o bienestar propios o ajenos.<\\/p><p>Cumplimiento de la Ley de protecci\\u00f3n de la privacidad en l\\u00ednea de los ni\\u00f1os<\\/p><p>Cumplimos con los requisitos previos de COPPA (Ley de protecci\\u00f3n de la privacidad en l\\u00ednea de los ni\\u00f1os), no recopilamos datos de personas menores de 13 a\\u00f1os. Nuestro sitio, art\\u00edculos y administraciones est\\u00e1n completamente coordinados para personas que tienen al menos 13 a\\u00f1os de edad o m\\u00e1s establecidas.<\\/p><p>Cambios a nuestra Pol\\u00edtica de Privacidad<\\/p><p>Si decidimos cambiar nuestra pol\\u00edtica de privacidad, publicaremos esos cambios en esta p\\u00e1gina.<\\/p><p>\\u00bfCu\\u00e1nto tiempo retenemos su informaci\\u00f3n?<\\/p><p>En el momento en que se registra en nuestro sitio, ciclamos y mantenemos la informaci\\u00f3n que tenemos sobre usted por el tiempo que no borre el registro o se retire (sujeto a leyes y pautas).<\\/p>\"}}}',1,1,'2024-09-02 23:57:50','2024-09-02 23:57:50');
/*!40000 ALTER TABLE `setup_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setup_seos`
--

DROP TABLE IF EXISTS `setup_seos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setup_seos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc` text COLLATE utf8mb4_unicode_ci,
  `tags` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_edit_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `setup_seos_last_edit_by_foreign` (`last_edit_by`),
  CONSTRAINT `setup_seos_last_edit_by_foreign` FOREIGN KEY (`last_edit_by`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setup_seos`
--

LOCK TABLES `setup_seos` WRITE;
/*!40000 ALTER TABLE `setup_seos` DISABLE KEYS */;
INSERT INTO `setup_seos` VALUES (1,'strip-card','StripCard- Virtual Credit Card Solution','StripCard is a software application used to conduct an online chat conversation for text and image, in lieu of providing direct contact with a live human agent. It is capable of maintaining a conversation with a user in natural language, understanding their intent, and replying based on preset rules and data.','[\"24\\/7 support\",\"card issuance\",\"customizable\",\"easy setup\",\"financial inclusion\",\"one-time-use codes\",\"online payments\",\"payment solutions\",\"secure transactions\",\"sleek design\",\"User-Friendly interface\",\"virtual credit cards\"]','seeder/seo_image.jpg',1,'2024-09-02 23:57:50','2024-09-02 23:57:50');
/*!40000 ALTER TABLE `setup_seos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_sections`
--

DROP TABLE IF EXISTS `site_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_sections` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `serialize` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_sections`
--

LOCK TABLES `site_sections` WRITE;
/*!40000 ALTER TABLE `site_sections` DISABLE KEYS */;
INSERT INTO `site_sections` VALUES (1,'site_cookie','{\"status\":true,\"link\":\"page\\/privacy-policy\",\"desc\":\"<p><span style=\\\"color:hsl(0,0%,0%);\\\">We may use cookies or any other tracking technologies when you visit our website, including any other media form, mobile website, or mobile application related or connected to help customize the Site and improve your experience.<\\/span><\\/p><p>&nbsp;<\\/p>\"}',1,NULL,NULL,NULL),(2,'home-banner','{\"images\":{\"banner_image\":\"3770d1fc-37bf-4a7a-9e5d-170883df5df9.webp\"},\"language\":{\"en\":{\"heading\":\"Unveiling the Virtual Credit Card Experience\",\"sub_heading\":\"The payment needs of major online giants such as AliExpress, Netflix, Facebook-Google Advertising, Amazon, and various other shopping platforms.\",\"button_name\":\"Apply Virtual Card\",\"button_link\":\"contact\"},\"es\":{\"heading\":\"Presentando la experiencia de la tarjeta de cr\\u00e9dito virtual\",\"sub_heading\":\"Las necesidades de pago de los principales gigantes en l\\u00ednea como AliExpress, Netflix, Facebook-Google Advertising, Amazon y varias otras plataformas de compras.\",\"button_name\":\"Aplicar Tarjeta Virtual\",\"button_link\":\"contact\"},\"ar\":{\"heading\":\"\\u0627\\u0644\\u0643\\u0634\\u0641 \\u0639\\u0646 \\u062a\\u062c\\u0631\\u0628\\u0629 \\u0628\\u0637\\u0627\\u0642\\u0629 \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629\",\"sub_heading\":\"\\u0627\\u062d\\u062a\\u064a\\u0627\\u062c\\u0627\\u062a \\u0627\\u0644\\u062f\\u0641\\u0639 \\u0644\\u0643\\u0628\\u0627\\u0631 \\u0639\\u0645\\u0627\\u0644\\u0642\\u0629 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a \\u0645\\u062b\\u0644 AliExpress \\u0648Netflix \\u0648Facebook-Google Advertising \\u0648Amazon \\u0648\\u0627\\u0644\\u0639\\u062f\\u064a\\u062f \\u0645\\u0646 \\u0645\\u0646\\u0635\\u0627\\u062a \\u0627\\u0644\\u062a\\u0633\\u0648\\u0642 \\u0627\\u0644\\u0623\\u062e\\u0631\\u0649.\",\"button_name\":\"\\u062a\\u0637\\u0628\\u064a\\u0642 \\u0627\\u0644\\u0628\\u0637\\u0627\\u0642\\u0629 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629\",\"button_link\":\"contact\"},\"cn\":{\"heading\":\"0\\u95e8\\u69db\\uff0c\\u6781\\u901f\\u5f00\\u901a\",\"sub_heading\":\"\\u5feb\\u901f\\u7533\\u8bf7Visa\\uff5cMaster\\u865a\\u62df\\u5361\\uff0c\\u8986\\u76d6\\u591a\\u79cd\\u6d88\\u8d39\\u573a\\u666f\\uff0c\\u5168\\u5e01\\u79cd\\u7ed3\\u7b97\\uff0c\\u72ec\\u7acb\\u540e\\u53f0\\uff0c\\u5f00\\u5361\\u5373\\u7528\\uff0c\\u4e00\\u7ad9\\u5f0f\\u89e3\\u51b3\\u6d77\\u5916\\u652f\\u4ed8\\u95ee\\u9898\\uff01\",\"button_name\":\"\\u7acb\\u5373\\u5f00\\u5361\",\"button_link\":\"user\"}}}',1,NULL,NULL,'2024-09-03 06:16:43'),(3,'about-section','{\"images\":{\"banner_image\":\"88c1be66-6038-438e-8b7c-64a6b3356a71.webp\",\"first_section_image\":\"afbb5b41-2bed-47c9-a82a-ef16751d8f90.webp\",\"second_section_image\":\"e3261cd8-8861-42cd-9df4-152bdc126b57.webp\",\"image\":\"98d8b2de-c267-484a-8316-b5d518570c10.webp\"},\"language\":{\"en\":{\"section_title\":\"About Us\",\"heading\":\"Empowering the Future of Online Transactions\",\"sub_heading\":\"we are at the forefront of revolutionizing the way people navigate the digital financial landscape. Our mission is clear: to provide users and entrepreneurs with a secure, efficient, and user-friendly platform for conducting online transactions through virtual credit cards.\"},\"es\":{\"section_title\":\"Sobre nosotras\",\"heading\":\"Potenciando el futuro de las transacciones en l\\u00ednea\",\"sub_heading\":\"Estamos a la vanguardia de revolucionar la forma en que las personas navegan por el panorama financiero digital. Nuestra misi\\u00f3n es clara: brindar a usuarios y emprendedores una plataforma segura, eficiente y amigable para realizar transacciones en l\\u00ednea a trav\\u00e9s de tarjetas de cr\\u00e9dito virtuales.\"},\"ar\":{\"section_title\":\"\\u0645\\u0639\\u0644\\u0648\\u0645\\u0627\\u062a \\u0639\\u0646\\u0627\",\"heading\":\"\\u062a\\u0645\\u0643\\u064a\\u0646 \\u0645\\u0633\\u062a\\u0642\\u0628\\u0644 \\u0627\\u0644\\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a\",\"sub_heading\":\"\\u0646\\u062d\\u0646 \\u0641\\u064a \\u0637\\u0644\\u064a\\u0639\\u0629 \\u0625\\u062d\\u062f\\u0627\\u062b \\u062b\\u0648\\u0631\\u0629 \\u0641\\u064a \\u0627\\u0644\\u0637\\u0631\\u064a\\u0642\\u0629 \\u0627\\u0644\\u062a\\u064a \\u064a\\u062a\\u0646\\u0642\\u0644 \\u0628\\u0647\\u0627 \\u0627\\u0644\\u0623\\u0634\\u062e\\u0627\\u0635 \\u0641\\u064a \\u0627\\u0644\\u0645\\u0634\\u0647\\u062f \\u0627\\u0644\\u0645\\u0627\\u0644\\u064a \\u0627\\u0644\\u0631\\u0642\\u0645\\u064a. \\u0645\\u0647\\u0645\\u062a\\u0646\\u0627 \\u0648\\u0627\\u0636\\u062d\\u0629: \\u062a\\u0632\\u0648\\u064a\\u062f \\u0627\\u0644\\u0645\\u0633\\u062a\\u062e\\u062f\\u0645\\u064a\\u0646 \\u0648\\u0631\\u062c\\u0627\\u0644 \\u0627\\u0644\\u0623\\u0639\\u0645\\u0627\\u0644 \\u0628\\u0645\\u0646\\u0635\\u0629 \\u0622\\u0645\\u0646\\u0629 \\u0648\\u0641\\u0639\\u0627\\u0644\\u0629 \\u0648\\u0633\\u0647\\u0644\\u0629 \\u0627\\u0644\\u0627\\u0633\\u062a\\u062e\\u062f\\u0627\\u0645 \\u0644\\u0625\\u062c\\u0631\\u0627\\u0621 \\u0627\\u0644\\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a \\u0645\\u0646 \\u062e\\u0644\\u0627\\u0644 \\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629.\"}},\"items\":{\"643eb4e71fe4e\":{\"language\":{\"en\":{\"title\":\"Our Vision\",\"icon\":\"fas fa-check\"},\"es\":{\"title\":\"Nuestra visi\\u00f3n\",\"icon\":\"fas fa-check\"},\"ar\":{\"title\":\"\\u0631\\u0624\\u064a\\u062a\\u0646\\u0627\",\"icon\":\"fas fa-check\"}},\"id\":\"643eb4e71fe4e\"},\"643eb5ed48d64\":{\"language\":{\"en\":{\"title\":\"The StripCard Difference\",\"icon\":\"fas fa-check\"},\"es\":{\"title\":\"La diferencia con StripCard\",\"icon\":\"transacci\\u00f3n de recibos\"},\"ar\":{\"title\":\"\\u0627\\u0644\\u0641\\u0631\\u0642 StripCard\",\"icon\":\"fas fa-check\"}},\"id\":\"643eb5ed48d64\"},\"643eb61b0a83f\":{\"language\":{\"en\":{\"title\":\"Our Commitment\",\"icon\":\"fas fa-check\"},\"es\":{\"title\":\"Nuestro compromiso\",\"icon\":\"fas fa-check\"},\"ar\":{\"title\":\"\\u0627\\u0644\\u062a\\u0632\\u0627\\u0645\\u0646\\u0627\",\"icon\":\"fas fa-check\"}},\"id\":\"643eb61b0a83f\"},\"643eb6396376b\":{\"language\":{\"en\":{\"title\":\"Join Us on this Journey\",\"icon\":\"fas fa-check\"},\"es\":{\"title\":\"\\u00danete a nosotros en este viaje\",\"icon\":\"fas fa-check\"},\"ar\":{\"title\":\"\\u0627\\u0646\\u0636\\u0645 \\u0625\\u0644\\u064a\\u0646\\u0627 \\u0641\\u064a \\u0647\\u0630\\u0647 \\u0627\\u0644\\u0631\\u062d\\u0644\\u0629\",\"icon\":\"fas fa-check\"}},\"id\":\"643eb6396376b\"}}}',1,NULL,NULL,'2023-11-06 04:13:09'),(4,'testimonials-section','{\"language\":{\"en\":{\"title\":\"What Our Users Are Saying\",\"sub_heading\":\"Explore what our satisfied users have to say about their experiences with it.\"},\"es\":{\"title\":\"Lo que nuestras usuarias est\\u00e1n diciendo\",\"sub_heading\":\"Explore lo que nuestros usuarios satisfechos tienen que decir sobre sus experiencias con \\u00e9l.\"},\"ar\":{\"title\":\"\\u0645\\u0627 \\u064a\\u0642\\u0648\\u0644\\u0647 \\u0645\\u0633\\u062a\\u062e\\u062f\\u0645\\u0648\\u0646\\u0627\",\"sub_heading\":\"\\u0627\\u0643\\u062a\\u0634\\u0641 \\u0645\\u0627 \\u064a\\u0642\\u0648\\u0644\\u0647 \\u0645\\u0633\\u062a\\u062e\\u062f\\u0645\\u0648\\u0646\\u0627 \\u0627\\u0644\\u0631\\u0627\\u0636\\u0648\\u0646 \\u0639\\u0646 \\u062a\\u062c\\u0627\\u0631\\u0628\\u0647\\u0645 \\u0645\\u0639\\u0647.\"}},\"items\":{\"643820a97ee03\":{\"language\":{\"en\":{\"name\":\"Sarah Williams\",\"designation\":\"Marketing Manager\",\"rating\":\"5\",\"details\":\"\\u201cStripCard has completely transformed the way we handle online transactions in our company. The security features are top-notch, and the ease of generating virtual cards makes our online purchases hassle-free. I highly recommend StripCard to anyone looking for a secure and convenient online payment solution.\\u201d\"},\"es\":{\"name\":\"Sara Williams\",\"designation\":\"Gerente de Mercadeo\",\"rating\":\"5\",\"details\":\"\\u201cStripCard ha transformado completamente la forma en que manejamos las transacciones en l\\u00ednea en nuestra empresa. Las caracter\\u00edsticas de seguridad son de primer nivel y la facilidad para generar tarjetas virtuales hace que nuestras compras en l\\u00ednea sean sencillas. Recomiendo ampliamente StripCard a cualquiera que busque una soluci\\u00f3n de pago en l\\u00ednea segura y conveniente\\u201d.\"},\"ar\":{\"name\":\"\\u0633\\u0627\\u0631\\u0629 \\u0648\\u064a\\u0644\\u064a\\u0627\\u0645\\u0632\",\"designation\":\"\\u0645\\u062f\\u064a\\u0631 \\u062a\\u0633\\u0648\\u064a\\u0642\",\"rating\":\"5\",\"details\":\"\\\"\\u0644\\u0642\\u062f \\u063a\\u064a\\u0631\\u062a StripCard \\u062a\\u0645\\u0627\\u0645\\u064b\\u0627 \\u0627\\u0644\\u0637\\u0631\\u064a\\u0642\\u0629 \\u0627\\u0644\\u062a\\u064a \\u0646\\u062a\\u0639\\u0627\\u0645\\u0644 \\u0628\\u0647\\u0627 \\u0645\\u0639 \\u0627\\u0644\\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a \\u0641\\u064a \\u0634\\u0631\\u0643\\u062a\\u0646\\u0627. \\u062a\\u062a\\u0645\\u064a\\u0632 \\u0645\\u064a\\u0632\\u0627\\u062a \\u0627\\u0644\\u0623\\u0645\\u0627\\u0646 \\u0628\\u0623\\u0646\\u0647\\u0627 \\u0645\\u0646 \\u0627\\u0644\\u0637\\u0631\\u0627\\u0632 \\u0627\\u0644\\u0623\\u0648\\u0644\\u060c \\u0643\\u0645\\u0627 \\u0623\\u0646 \\u0633\\u0647\\u0648\\u0644\\u0629 \\u0625\\u0646\\u0634\\u0627\\u0621 \\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629 \\u062a\\u062c\\u0639\\u0644 \\u0639\\u0645\\u0644\\u064a\\u0627\\u062a \\u0627\\u0644\\u0634\\u0631\\u0627\\u0621 \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a \\u062e\\u0627\\u0644\\u064a\\u0629 \\u0645\\u0646 \\u0627\\u0644\\u0645\\u062a\\u0627\\u0639\\u0628. \\u0623\\u0648\\u0635\\u064a \\u0628\\u0634\\u062f\\u0629 \\u0628\\u0640 StripCard \\u0644\\u0623\\u064a \\u0634\\u062e\\u0635 \\u064a\\u0628\\u062d\\u062b \\u0639\\u0646 \\u062d\\u0644 \\u0622\\u0645\\u0646 \\u0648\\u0645\\u0631\\u064a\\u062d \\u0644\\u0644\\u062f\\u0641\\u0639 \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a.\"}},\"id\":\"643820a97ee03\",\"image\":\"2e7cc167-a7cd-4031-a97c-04ec1db1c445.webp\"},\"64382127cf532\":{\"language\":{\"en\":{\"name\":\"John Smith\",\"designation\":\"Small Business Owner\",\"rating\":\"4\",\"details\":\"\\u201cAs a small business owner, StripCard has been a game-changer. It allows me to offer convenient payment options to my clients while generating an extra revenue stream. The one-time-use codes provide peace of mind, knowing that my transactions are secure. StripCard is a win-win for both my clients and my business.\\u201d\"},\"es\":{\"name\":\"John Smith\",\"designation\":\"Propietario de un peque\\u00f1o negocio\",\"rating\":\"4\",\"details\":\"\\u201cComo propietario de una peque\\u00f1a empresa, StripCard ha cambiado las reglas del juego. Me permite ofrecer opciones de pago convenientes a mis clientes y al mismo tiempo generar un flujo de ingresos adicional. Los c\\u00f3digos de un solo uso brindan la tranquilidad de saber que mis transacciones son seguras. StripCard es beneficioso tanto para mis clientes como para mi negocio\\u201d.\"},\"ar\":{\"name\":\"\\u062c\\u0648\\u0646 \\u0633\\u0645\\u064a\\u062b\",\"designation\":\"\\u0635\\u0627\\u062d\\u0628 \\u0645\\u0634\\u0631\\u0648\\u0639 \\u0635\\u063a\\u064a\\u0631\",\"rating\":\"4\",\"details\":\"\\\"\\u0628\\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\u0647\\u0627 \\u0645\\u0627\\u0644\\u0643\\u064b\\u0627 \\u0644\\u0634\\u0631\\u0643\\u0629 \\u0635\\u063a\\u064a\\u0631\\u0629\\u060c \\u0641\\u0642\\u062f \\u063a\\u064a\\u0631\\u062a StripCard \\u0642\\u0648\\u0627\\u0639\\u062f \\u0627\\u0644\\u0644\\u0639\\u0628\\u0629. \\u0641\\u0647\\u0648 \\u064a\\u062a\\u064a\\u062d \\u0644\\u064a \\u062a\\u0642\\u062f\\u064a\\u0645 \\u062e\\u064a\\u0627\\u0631\\u0627\\u062a \\u062f\\u0641\\u0639 \\u0645\\u0646\\u0627\\u0633\\u0628\\u0629 \\u0644\\u0639\\u0645\\u0644\\u0627\\u0626\\u064a \\u0645\\u0639 \\u062a\\u0648\\u0644\\u064a\\u062f \\u062a\\u062f\\u0641\\u0642 \\u0625\\u0636\\u0627\\u0641\\u064a \\u0644\\u0644\\u0625\\u064a\\u0631\\u0627\\u062f\\u0627\\u062a. \\u062a\\u0648\\u0641\\u0631 \\u0631\\u0645\\u0648\\u0632 \\u0627\\u0644\\u0627\\u0633\\u062a\\u062e\\u062f\\u0627\\u0645 \\u0644\\u0645\\u0631\\u0629 \\u0648\\u0627\\u062d\\u062f\\u0629 \\u0631\\u0627\\u062d\\u0629 \\u0627\\u0644\\u0628\\u0627\\u0644\\u060c \\u0645\\u0639 \\u0627\\u0644\\u0639\\u0644\\u0645 \\u0623\\u0646 \\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a\\u064a \\u0622\\u0645\\u0646\\u0629. \\u064a\\u0639\\u062f StripCard \\u0645\\u0631\\u0628\\u062d\\u064b\\u0627 \\u0644\\u0643\\u0644 \\u0645\\u0646 \\u0639\\u0645\\u0644\\u0627\\u0626\\u064a \\u0648\\u0639\\u0645\\u0644\\u064a.\"}},\"id\":\"64382127cf532\",\"image\":\"11a9a3a2-3061-4bac-b7ae-ef630df7f563.webp\"},\"6438252b52033\":{\"language\":{\"en\":{\"name\":\"Lisa Rodriguez\",\"designation\":\"Online Shopper\",\"rating\":\"5\",\"details\":\"\\u201cShopping online has never been this secure and straightforward. StripCard\\u2019s unique codes make me feel confident about the safety of my transactions. It\\u2019s like having an extra layer of protection. I can\\u2019t imagine going back to using my regular card for online purchases. StripCard has won me over!\\u201d\"},\"es\":{\"name\":\"Lisa Rodriguez\",\"designation\":\"Comprador en l\\u00ednea\",\"rating\":\"5\",\"details\":\"\\u201cComprar online nunca ha sido tan seguro y sencillo. Los c\\u00f3digos \\u00fanicos de StripCard me hacen sentir seguro sobre la seguridad de mis transacciones. Es como tener una capa extra de protecci\\u00f3n. No me imagino volver a utilizar mi tarjeta habitual para compras online. \\u00a1StripCard me ha convencido!\\u201d\"},\"ar\":{\"name\":\"\\u0644\\u064a\\u0632\\u0627 \\u0631\\u0648\\u062f\\u0631\\u064a\\u062c\\u064a\\u0632\",\"designation\":\"\\u0627\\u0644\\u0634\\u0631\\u0627\\u0621 \\u0639\\u0644\\u0627\\u0646\\u062a\\u0631\\u0646\\u064a\\u062a\",\"rating\":\"5\",\"details\":\"\\\"\\u0644\\u0645 \\u064a\\u0643\\u0646 \\u0627\\u0644\\u062a\\u0633\\u0648\\u0642 \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a \\u0628\\u0647\\u0630\\u0647 \\u0627\\u0644\\u062f\\u0631\\u062c\\u0629 \\u0645\\u0646 \\u0627\\u0644\\u0623\\u0645\\u0627\\u0646 \\u0648\\u0627\\u0644\\u0628\\u0633\\u0627\\u0637\\u0629 \\u0645\\u0646 \\u0642\\u0628\\u0644. \\u0631\\u0645\\u0648\\u0632 StripCard \\u0627\\u0644\\u0641\\u0631\\u064a\\u062f\\u0629 \\u062a\\u062c\\u0639\\u0644\\u0646\\u064a \\u0623\\u0634\\u0639\\u0631 \\u0628\\u0627\\u0644\\u062b\\u0642\\u0629 \\u0628\\u0634\\u0623\\u0646 \\u0633\\u0644\\u0627\\u0645\\u0629 \\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a\\u064a. \\u0625\\u0646\\u0647 \\u0645\\u062b\\u0644 \\u0648\\u062c\\u0648\\u062f \\u0637\\u0628\\u0642\\u0629 \\u0625\\u0636\\u0627\\u0641\\u064a\\u0629 \\u0645\\u0646 \\u0627\\u0644\\u062d\\u0645\\u0627\\u064a\\u0629. \\u0644\\u0627 \\u0623\\u0633\\u062a\\u0637\\u064a\\u0639 \\u0623\\u0646 \\u0623\\u062a\\u062e\\u064a\\u0644 \\u0627\\u0644\\u0639\\u0648\\u062f\\u0629 \\u0625\\u0644\\u0649 \\u0627\\u0633\\u062a\\u062e\\u062f\\u0627\\u0645 \\u0628\\u0637\\u0627\\u0642\\u062a\\u064a \\u0627\\u0644\\u0639\\u0627\\u062f\\u064a\\u0629 \\u0644\\u0639\\u0645\\u0644\\u064a\\u0627\\u062a \\u0627\\u0644\\u0634\\u0631\\u0627\\u0621 \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a. \\u0644\\u0642\\u062f \\u0641\\u0627\\u0632 \\u0628\\u064a StripCard!\"}},\"id\":\"6438252b52033\",\"image\":\"e0140d7d-0a56-4201-b99b-27efc561f565.webp\"}}}',1,NULL,NULL,'2023-11-06 04:27:48'),(5,'contact','{\"language\":{\"en\":{\"title\":\"Contact Us\",\"heading\":\"Feel Free To Get In Touch With Us\",\"infomation\":\"We\\u2019d love to hear from you! If you have any questions or need assistance, please don\\u2019t hesitate to get in touch with us using the following contact information:\",\"address\":\"1234 Main Street City, State 56789 USA\",\"phone\":\"+1 (123) 456-7890\",\"email\":\"info@example.com\"},\"es\":{\"title\":\"Contacta con nosotra\",\"heading\":\"Si\\u00e9ntase libre de ponerse en contacto con nosotras\",\"infomation\":\"\\u00a1Nos encantar\\u00eda saber de usted! Si tiene alguna pregunta o necesita ayuda, no dude en ponerse en contacto con nosotros utilizando la siguiente informaci\\u00f3n de contacto:\",\"address\":\"1234 Main Street Ciudad, Estado 56789 EE. UU.\",\"phone\":\"+1 (123) 456-7890\",\"email\":\"info@example.com\"},\"ar\":{\"title\":\"\\u0627\\u062a\\u0635\\u0644 \\u0628\\u0646\\u0627\",\"heading\":\"\\u0644\\u0627 \\u062a\\u062a\\u0631\\u062f\\u062f \\u0641\\u064a \\u0627\\u0644\\u062a\\u0648\\u0627\\u0635\\u0644 \\u0645\\u0639\\u0646\\u0627\",\"infomation\":\"\\u0646\\u062d\\u0646 \\u0646\\u062d\\u0628 \\u0623\\u0646 \\u0646\\u0633\\u0645\\u0639 \\u0645\\u0646\\u0643! \\u0625\\u0630\\u0627 \\u0643\\u0627\\u0646 \\u0644\\u062f\\u064a\\u0643 \\u0623\\u064a \\u0623\\u0633\\u0626\\u0644\\u0629 \\u0623\\u0648 \\u0643\\u0646\\u062a \\u0628\\u062d\\u0627\\u062c\\u0629 \\u0625\\u0644\\u0649 \\u0627\\u0644\\u0645\\u0633\\u0627\\u0639\\u062f\\u0629\\u060c \\u0641\\u0644\\u0627 \\u062a\\u062a\\u0631\\u062f\\u062f \\u0641\\u064a \\u0627\\u0644\\u0627\\u062a\\u0635\\u0627\\u0644 \\u0628\\u0646\\u0627 \\u0628\\u0627\\u0633\\u062a\\u062e\\u062f\\u0627\\u0645 \\u0645\\u0639\\u0644\\u0648\\u0645\\u0627\\u062a \\u0627\\u0644\\u0627\\u062a\\u0635\\u0627\\u0644 \\u0627\\u0644\\u062a\\u0627\\u0644\\u064a\\u0629:\",\"address\":\"1234 \\u0645\\u064a\\u0646 \\u0633\\u062a\\u0631\\u064a\\u062a \\u0633\\u064a\\u062a\\u064a\\u060c \\u0627\\u0644\\u0648\\u0644\\u0627\\u064a\\u0629 56789 \\u0627\\u0644\\u0648\\u0644\\u0627\\u064a\\u0627\\u062a \\u0627\\u0644\\u0645\\u062a\\u062d\\u062f\\u0629 \\u0627\\u0644\\u0623\\u0645\\u0631\\u064a\\u0643\\u064a\\u0629\",\"phone\":\"+1 (123) 456-7890\",\"email\":\"info@example.com\"}}}',1,NULL,NULL,'2023-11-06 04:51:38'),(6,'footer-section','{\"language\":{\"en\":{\"footer_text\":\"Copyright \\u00a9 2023 , All Rights Reserved.\",\"details\":\"Thank you for choosing StripCard as your trusted partner for secure online transactions. We are committed to providing you with a seamless and secure experience.\"},\"es\":{\"footer_text\":\"Copyright \\u00a9 2023, Todos los derechos reservados.\",\"details\":\"Gracias por elegir StripCard como su socio de confianza para transacciones seguras en l\\u00ednea. Estamos comprometidos a brindarle una experiencia fluida y segura.\"},\"ar\":{\"footer_text\":\"\\u062d\\u0642\\u0648\\u0642 \\u0627\\u0644\\u0646\\u0634\\u0631 \\u00a9 2023\\u060c \\u062c\\u0645\\u064a\\u0639 \\u0627\\u0644\\u062d\\u0642\\u0648\\u0642 \\u0645\\u062d\\u0641\\u0648\\u0638\\u0629.\",\"details\":\"\\u0646\\u0634\\u0643\\u0631\\u0643 \\u0639\\u0644\\u0649 \\u0627\\u062e\\u062a\\u064a\\u0627\\u0631 StripCard \\u0643\\u0634\\u0631\\u064a\\u0643 \\u0645\\u0648\\u062b\\u0648\\u0642 \\u0628\\u0647 \\u0644\\u0625\\u062c\\u0631\\u0627\\u0621 \\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a \\u0622\\u0645\\u0646\\u0629 \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a. \\u0646\\u062d\\u0646 \\u0645\\u0644\\u062a\\u0632\\u0645\\u0648\\u0646 \\u0628\\u062a\\u0632\\u0648\\u064a\\u062f\\u0643 \\u0628\\u062a\\u062c\\u0631\\u0628\\u0629 \\u0633\\u0644\\u0633\\u0629 \\u0648\\u0622\\u0645\\u0646\\u0629.\"}},\"items\":{\"643ec92bddaae\":{\"language\":{\"en\":{\"name\":\"Facebook\",\"social_icon\":\"fab fa-facebook\",\"link\":\"https:\\/\\/facebook.com\\/\"},\"es\":{\"name\":\"Facebook\",\"social_icon\":\"fab fa-facebook\",\"link\":\"https:\\/\\/facebook.com\\/\"},\"ar\":{\"name\":\"\\u0641\\u064a\\u0633\\u0628\\u0648\\u0643\",\"social_icon\":\"fab fa-facebook\",\"link\":\"https:\\/\\/facebook.com\\/\"}},\"id\":\"643ec92bddaae\"},\"643ec94c4769c\":{\"language\":{\"en\":{\"name\":\"Instagram\",\"social_icon\":\"fab fa-instagram\",\"link\":\"https:\\/\\/www.instagram.com\\/\"},\"es\":{\"name\":\"Instagram\",\"social_icon\":\"fab fa-instagram\",\"link\":\"https:\\/\\/www.instagram.com\\/\"},\"ar\":{\"name\":\"\\u0627\\u0646\\u0633\\u062a\\u063a\\u0631\\u0627\\u0645\",\"social_icon\":\"fab fa-instagram\",\"link\":\"https:\\/\\/www.instagram.com\\/\"}},\"id\":\"643ec94c4769c\"},\"643ec96763812\":{\"language\":{\"en\":{\"name\":\"Twitter\",\"social_icon\":\"fab fa-twitter\",\"link\":\"https:\\/\\/twitter.com\\/login\"},\"es\":{\"name\":\"Twitter\",\"social_icon\":\"fab fa-twitter\",\"link\":\"https:\\/\\/twitter.com\\/login\"},\"ar\":{\"name\":\"\\u062a\\u0648\\u064a\\u062a\\u0631\",\"social_icon\":\"fab fa-twitter\",\"link\":\"https:\\/\\/twitter.com\\/login\"}},\"id\":\"643ec96763812\"}}}',1,NULL,NULL,'2023-11-06 05:01:31'),(7,'our-features','{\"language\":{\"en\":{\"heading\":\"Our Features\",\"sub_heading\":\"Redefining Online Transactions\",\"details\":\"Discover the unparalleled features that make StripCard the go-to platform for secure, convenient, and efficient online transactions. With our virtual credit cards, you can seamlessly shop, subscribe, and transact online, all with just a few clicks.\"},\"es\":{\"heading\":\"Nuestras caracter\\u00edsticas\",\"sub_heading\":\"Redefiniendo las transacciones en l\\u00ednea\",\"details\":\"Descubra las caracter\\u00edsticas incomparables que hacen de StripCard la plataforma ideal para transacciones en l\\u00ednea seguras, convenientes y eficientes. Con nuestras tarjetas de cr\\u00e9dito virtuales, puede comprar, suscribirse y realizar transacciones en l\\u00ednea sin problemas, todo con solo unos pocos clics.\"},\"ar\":{\"heading\":\"\\u0645\\u0645\\u064a\\u0632\\u0627\\u062a\\u0646\\u0627\",\"sub_heading\":\"\\u0625\\u0639\\u0627\\u062f\\u0629 \\u062a\\u0639\\u0631\\u064a\\u0641 \\u0627\\u0644\\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a\",\"details\":\"\\u0627\\u0643\\u062a\\u0634\\u0641 \\u0627\\u0644\\u0645\\u064a\\u0632\\u0627\\u062a \\u0627\\u0644\\u062a\\u064a \\u0644\\u0627 \\u0645\\u062b\\u064a\\u0644 \\u0644\\u0647\\u0627 \\u0648\\u0627\\u0644\\u062a\\u064a \\u062a\\u062c\\u0639\\u0644 StripCard \\u0645\\u0646\\u0635\\u0629 \\u0627\\u0644\\u0627\\u0646\\u062a\\u0642\\u0627\\u0644 \\u0644\\u0644\\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a \\u0627\\u0644\\u0622\\u0645\\u0646\\u0629 \\u0648\\u0627\\u0644\\u0645\\u0631\\u064a\\u062d\\u0629 \\u0648\\u0627\\u0644\\u0641\\u0639\\u0627\\u0644\\u0629 \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a. \\u0628\\u0627\\u0633\\u062a\\u062e\\u062f\\u0627\\u0645 \\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629 \\u0627\\u0644\\u062e\\u0627\\u0635\\u0629 \\u0628\\u0646\\u0627\\u060c \\u064a\\u0645\\u0643\\u0646\\u0643 \\u0627\\u0644\\u062a\\u0633\\u0648\\u0642 \\u0648\\u0627\\u0644\\u0627\\u0634\\u062a\\u0631\\u0627\\u0643 \\u0648\\u0627\\u0644\\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a \\u0628\\u0633\\u0644\\u0627\\u0633\\u0629\\u060c \\u0643\\u0644 \\u0630\\u0644\\u0643 \\u0628\\u0628\\u0636\\u0639 \\u0646\\u0642\\u0631\\u0627\\u062a \\u0641\\u0642\\u0637.\"}},\"items\":{\"643eb72c2c42f\":{\"language\":{\"en\":{\"title\":\"Virtual Credit Cards\",\"sub_title\":\"Say goodbye to the limitations of physical credit cards.\"},\"es\":{\"title\":\"Tarjetas de cr\\u00e9dito virtuales\",\"sub_title\":\"Dile adi\\u00f3s a las limitaciones de las tarjetas de cr\\u00e9dito f\\u00edsicas.\"},\"ar\":{\"title\":\"\\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629\",\"sub_title\":\"\\u0642\\u0644 \\u0648\\u062f\\u0627\\u0639\\u064b\\u0627 \\u0644\\u0644\\u0642\\u064a\\u0648\\u062f \\u0627\\u0644\\u0645\\u0641\\u0631\\u0648\\u0636\\u0629 \\u0639\\u0644\\u0649 \\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0645\\u0627\\u062f\\u064a\\u0629.\"}},\"id\":\"643eb72c2c42f\"},\"643eb745b1758\":{\"language\":{\"en\":{\"title\":\"Cutting-Edge Security\",\"sub_title\":\"We employ state-of-the-art encryption and security protocols to ensure your financial data is protected at all times.\"},\"es\":{\"title\":\"Seguridad de vanguardia\",\"sub_title\":\"Empleamos protocolos de seguridad y cifrado de \\u00faltima generaci\\u00f3n para garantizar que sus datos financieros est\\u00e9n protegidos en todo momento.\"},\"ar\":{\"title\":\"\\u0627\\u0644\\u0623\\u0645\\u0646 \\u0627\\u0644\\u0645\\u062a\\u0637\\u0648\\u0631\",\"sub_title\":\"\\u0646\\u062d\\u0646 \\u0646\\u0633\\u062a\\u062e\\u062f\\u0645 \\u0623\\u062d\\u062f\\u062b \\u0628\\u0631\\u0648\\u062a\\u0648\\u0643\\u0648\\u0644\\u0627\\u062a \\u0627\\u0644\\u062a\\u0634\\u0641\\u064a\\u0631 \\u0648\\u0627\\u0644\\u0623\\u0645\\u0627\\u0646 \\u0644\\u0636\\u0645\\u0627\\u0646 \\u062d\\u0645\\u0627\\u064a\\u0629 \\u0628\\u064a\\u0627\\u0646\\u0627\\u062a\\u0643 \\u0627\\u0644\\u0645\\u0627\\u0644\\u064a\\u0629 \\u0641\\u064a \\u062c\\u0645\\u064a\\u0639 \\u0627\\u0644\\u0623\\u0648\\u0642\\u0627\\u062a.\"}},\"id\":\"643eb745b1758\"},\"643eb77aa0589\":{\"language\":{\"en\":{\"title\":\"Transparent Fee Structure\",\"sub_title\":\"It maintains a straightforward fee structure, ensuring you always know what to expect, with no surprises.\"},\"es\":{\"title\":\"Estructura de tarifas transparente\",\"sub_title\":\"Mantiene una estructura de tarifas sencilla, lo que garantiza que siempre sepa qu\\u00e9 esperar, sin sorpresas.\"},\"ar\":{\"title\":\"\\u0647\\u064a\\u0643\\u0644 \\u0631\\u0633\\u0648\\u0645 \\u0634\\u0641\\u0627\\u0641\",\"sub_title\":\"\\u0625\\u0646\\u0647 \\u064a\\u062d\\u0627\\u0641\\u0638 \\u0639\\u0644\\u0649 \\u0647\\u064a\\u0643\\u0644 \\u0631\\u0633\\u0648\\u0645 \\u0645\\u0628\\u0627\\u0634\\u0631\\u060c \\u0645\\u0645\\u0627 \\u064a\\u0636\\u0645\\u0646 \\u0623\\u0646\\u0643 \\u062a\\u0639\\u0631\\u0641 \\u062f\\u0627\\u0626\\u0645\\u064b\\u0627 \\u0645\\u0627 \\u064a\\u0645\\u0643\\u0646 \\u062a\\u0648\\u0642\\u0639\\u0647\\u060c \\u062f\\u0648\\u0646 \\u0623\\u064a \\u0645\\u0641\\u0627\\u062c\\u0622\\u062a.\"}},\"id\":\"643eb77aa0589\"},\"643eb794b9daa\":{\"language\":{\"en\":{\"title\":\"User-Friendly Interface\",\"sub_title\":\"Our platform boasts an intuitive, user-friendly interface, designed for both beginners and experienced users.\"},\"es\":{\"title\":\"Interfaz amigable\",\"sub_title\":\"Nuestra plataforma cuenta con una interfaz intuitiva y f\\u00e1cil de usar, dise\\u00f1ada tanto para principiantes como para usuarios experimentados.\"},\"ar\":{\"title\":\"\\u0648\\u0627\\u062c\\u0647\\u0629 \\u0633\\u0647\\u0644\\u0629 \\u0627\\u0644\\u0627\\u0633\\u062a\\u062e\\u062f\\u0627\\u0645\",\"sub_title\":\"\\u062a\\u062a\\u0645\\u064a\\u0632 \\u0645\\u0646\\u0635\\u062a\\u0646\\u0627 \\u0628\\u0648\\u0627\\u062c\\u0647\\u0629 \\u0628\\u062f\\u064a\\u0647\\u064a\\u0629 \\u0648\\u0633\\u0647\\u0644\\u0629 \\u0627\\u0644\\u0627\\u0633\\u062a\\u062e\\u062f\\u0627\\u0645\\u060c \\u0645\\u0635\\u0645\\u0645\\u0629 \\u0644\\u0643\\u0644 \\u0645\\u0646 \\u0627\\u0644\\u0645\\u0633\\u062a\\u062e\\u062f\\u0645\\u064a\\u0646 \\u0627\\u0644\\u0645\\u0628\\u062a\\u062f\\u0626\\u064a\\u0646 \\u0648\\u0630\\u0648\\u064a \\u0627\\u0644\\u062e\\u0628\\u0631\\u0629.\"}},\"id\":\"643eb794b9daa\"}}}',1,NULL,NULL,'2023-11-06 04:18:29'),(8,'work-section','{\"language\":{\"en\":{\"title\":\"How It is Work\",\"sub_title\":\"Flow Our Step For Create Your Accounttest\"},\"es\":{\"title\":\"como funciona\",\"sub_title\":\"Fluya nuestro paso para crear su cuenta.\"},\"ar\":{\"title\":\"\\u0643\\u064a\\u0641 \\u064a\\u062a\\u0645 \\u0627\\u0644\\u0639\\u0645\\u0644\",\"sub_title\":\"\\u0627\\u062a\\u0628\\u0639 \\u062e\\u0637\\u0648\\u062a\\u0646\\u0627 \\u0644\\u0625\\u0646\\u0634\\u0627\\u0621 \\u062d\\u0633\\u0627\\u0628\\u0643\"}},\"items\":{\"643eb81b49cb8\":{\"language\":{\"en\":{\"name\":\"Sign Up\",\"icon\":\"las la-user-circle\",\"details\":\"Begin by signing up on the StripCard platform. Provide the required information to create your account.\"},\"es\":{\"name\":\"Inscribirse\",\"icon\":\"las la-user-circle\",\"details\":\"Comience registr\\u00e1ndose en la plataforma StripCard. Proporcione la informaci\\u00f3n requerida para crear su cuenta.\"},\"ar\":{\"name\":\"\\u0627\\u0634\\u062a\\u0631\\u0627\\u0643\",\"icon\":\"las la-user-circle\",\"details\":\"\\u0627\\u0628\\u062f\\u0623 \\u0628\\u0627\\u0644\\u062a\\u0633\\u062c\\u064a\\u0644 \\u0641\\u064a \\u0645\\u0646\\u0635\\u0629 StripCard. \\u062a\\u0642\\u062f\\u064a\\u0645 \\u0627\\u0644\\u0645\\u0639\\u0644\\u0648\\u0645\\u0627\\u062a \\u0627\\u0644\\u0645\\u0637\\u0644\\u0648\\u0628\\u0629 \\u0644\\u0625\\u0646\\u0634\\u0627\\u0621 \\u062d\\u0633\\u0627\\u0628\\u0643.\"}},\"id\":\"643eb81b49cb8\"},\"643eb86734f8f\":{\"language\":{\"en\":{\"name\":\"Loading Funds\",\"icon\":\"las la-credit-card\",\"details\":\"This can be done through various payment methods, ensuring flexibility and convenience.\"},\"es\":{\"name\":\"Cargando fondos\",\"icon\":\"las la-credit-card\",\"details\":\"Esto se puede hacer a trav\\u00e9s de varios m\\u00e9todos de pago, lo que garantiza flexibilidad y comodidad.\"},\"ar\":{\"name\":\"\\u062a\\u062d\\u0645\\u064a\\u0644 \\u0627\\u0644\\u0623\\u0645\\u0648\\u0627\\u0644\",\"icon\":\"las la-credit-card\",\"details\":\"\\u0648\\u064a\\u0645\\u0643\\u0646 \\u0627\\u0644\\u0642\\u064a\\u0627\\u0645 \\u0628\\u0630\\u0644\\u0643 \\u0645\\u0646 \\u062e\\u0644\\u0627\\u0644 \\u0637\\u0631\\u0642 \\u0627\\u0644\\u062f\\u0641\\u0639 \\u0627\\u0644\\u0645\\u062e\\u062a\\u0644\\u0641\\u0629\\u060c \\u0645\\u0645\\u0627 \\u064a\\u0636\\u0645\\u0646 \\u0627\\u0644\\u0645\\u0631\\u0648\\u0646\\u0629 \\u0648\\u0627\\u0644\\u0631\\u0627\\u062d\\u0629.\"}},\"id\":\"643eb86734f8f\"},\"643eb8a0bb232\":{\"language\":{\"en\":{\"name\":\"Apply Virtual Card\",\"icon\":\"las la-paper-plane\",\"details\":\"It mirrors your traditional credit card, allowing you to conduct online transactions securely\"},\"es\":{\"name\":\"Aplicar Tarjeta Virtual\",\"icon\":\"las la-paper-plane\",\"details\":\"Refleja su tarjeta de cr\\u00e9dito tradicional, permiti\\u00e9ndole realizar transacciones en l\\u00ednea de forma segura\"},\"ar\":{\"name\":\"\\u062a\\u0637\\u0628\\u064a\\u0642 \\u0627\\u0644\\u0628\\u0637\\u0627\\u0642\\u0629 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629\",\"icon\":\"las la-paper-plane\",\"details\":\"\\u0625\\u0646\\u0647\\u0627 \\u062a\\u0639\\u0643\\u0633 \\u0628\\u0637\\u0627\\u0642\\u062a\\u0643 \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646\\u064a\\u0629 \\u0627\\u0644\\u062a\\u0642\\u0644\\u064a\\u062f\\u064a\\u0629\\u060c \\u0645\\u0645\\u0627 \\u064a\\u0633\\u0645\\u062d \\u0644\\u0643 \\u0628\\u0625\\u062c\\u0631\\u0627\\u0621 \\u0627\\u0644\\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a \\u0628\\u0634\\u0643\\u0644 \\u0622\\u0645\\u0646\"}},\"id\":\"643eb8a0bb232\"}}}',1,NULL,NULL,'2023-11-06 04:15:36'),(9,'service-section','{\"language\":{\"en\":{\"heading\":\"Service Provide\",\"sub_heading\":\"Our Upheld Administrations What We Serve To You\"},\"es\":{\"heading\":\"Servicio proporciona\",\"sub_heading\":\"Nuestras administraciones respaldadas Lo que le servimos\"},\"ar\":{\"heading\":\"\\u062a\\u0642\\u062f\\u064a\\u0645 \\u0627\\u0644\\u062e\\u062f\\u0645\\u0629\",\"sub_heading\":\"\\u0625\\u062f\\u0627\\u0631\\u0627\\u062a\\u0646\\u0627 \\u0627\\u0644\\u0645\\u0639\\u062a\\u0645\\u062f\\u0629 \\u0645\\u0627 \\u0646\\u062e\\u062f\\u0645\\u0647 \\u0644\\u0643\"}},\"items\":{\"6436efd57d87f\":{\"language\":{\"en\":{\"title\":\"Virtual Credit Card Creation\",\"sub_title\":\"Secure and convenient virtual credit card generation for online transactions, ensuring your financial data remains protected.\"},\"es\":{\"title\":\"Creaci\\u00f3n de tarjetas de cr\\u00e9dito virtuales\",\"sub_title\":\"Generaci\\u00f3n segura y conveniente de tarjetas de cr\\u00e9dito virtuales para transacciones en l\\u00ednea, lo que garantiza que sus datos financieros permanezcan protegidos.\"},\"ar\":{\"title\":\"\\u0625\\u0646\\u0634\\u0627\\u0621 \\u0628\\u0637\\u0627\\u0642\\u0629 \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629\",\"sub_title\":\"\\u0625\\u0646\\u0634\\u0627\\u0621 \\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629 \\u0622\\u0645\\u0646\\u0629 \\u0648\\u0645\\u0631\\u064a\\u062d\\u0629 \\u0644\\u0644\\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a\\u060c \\u0645\\u0645\\u0627 \\u064a\\u0636\\u0645\\u0646 \\u0628\\u0642\\u0627\\u0621 \\u0628\\u064a\\u0627\\u0646\\u0627\\u062a\\u0643 \\u0627\\u0644\\u0645\\u0627\\u0644\\u064a\\u0629 \\u0645\\u062d\\u0645\\u064a\\u0629.\"}},\"id\":\"6436efd57d87f\",\"image\":\"346b95cb-e7fe-431f-be49-6ca01c362dee.webp\"},\"6436efff890e3\":{\"language\":{\"en\":{\"title\":\"Entrepreneurial Partner Program\",\"sub_title\":\"Opportunities for entrepreneurs to expand their revenue streams by offering virtual credit card services to clients.\"},\"es\":{\"title\":\"Programa de Socios Emprendedores\",\"sub_title\":\"Oportunidades para que los empresarios ampl\\u00eden sus fuentes de ingresos ofreciendo servicios de tarjetas de cr\\u00e9dito virtuales a los clientes.\"},\"ar\":{\"title\":\"\\u0628\\u0631\\u0646\\u0627\\u0645\\u062c \\u0634\\u0631\\u0643\\u0627\\u0621 \\u0631\\u064a\\u0627\\u062f\\u0629 \\u0627\\u0644\\u0623\\u0639\\u0645\\u0627\\u0644\",\"sub_title\":\"\\u0641\\u0631\\u0635 \\u0644\\u0631\\u0648\\u0627\\u062f \\u0627\\u0644\\u0623\\u0639\\u0645\\u0627\\u0644 \\u0644\\u062a\\u0648\\u0633\\u064a\\u0639 \\u0645\\u0635\\u0627\\u062f\\u0631 \\u0625\\u064a\\u0631\\u0627\\u062f\\u0627\\u062a\\u0647\\u0645 \\u0645\\u0646 \\u062e\\u0644\\u0627\\u0644 \\u062a\\u0642\\u062f\\u064a\\u0645 \\u062e\\u062f\\u0645\\u0627\\u062a \\u0628\\u0637\\u0627\\u0642\\u0627\\u062a \\u0627\\u0644\\u0627\\u0626\\u062a\\u0645\\u0627\\u0646 \\u0627\\u0644\\u0627\\u0641\\u062a\\u0631\\u0627\\u0636\\u064a\\u0629 \\u0644\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621.\"}},\"id\":\"6436efff890e3\",\"image\":\"e8155f74-e5d6-41eb-b880-bc3d2bf8f2e2.webp\"},\"6436f026bdfe0\":{\"language\":{\"en\":{\"title\":\"User-Friendly Interface\",\"sub_title\":\"An intuitive and easy-to-navigate platform designed for both beginners and experienced users, making online transactions a breeze.\"},\"es\":{\"title\":\"Interfaz amigable\",\"sub_title\":\"Una plataforma intuitiva y f\\u00e1cil de navegar dise\\u00f1ada tanto para principiantes como para usuarios experimentados, que facilita las transacciones en l\\u00ednea.\"},\"ar\":{\"title\":\"\\u0648\\u0627\\u062c\\u0647\\u0629 \\u0633\\u0647\\u0644\\u0629 \\u0627\\u0644\\u0627\\u0633\\u062a\\u062e\\u062f\\u0627\\u0645\",\"sub_title\":\"\\u0645\\u0646\\u0635\\u0629 \\u0628\\u062f\\u064a\\u0647\\u064a\\u0629 \\u0648\\u0633\\u0647\\u0644\\u0629 \\u0627\\u0644\\u062a\\u0646\\u0642\\u0644 \\u0645\\u0635\\u0645\\u0645\\u0629 \\u0644\\u0643\\u0644 \\u0645\\u0646 \\u0627\\u0644\\u0645\\u0633\\u062a\\u062e\\u062f\\u0645\\u064a\\u0646 \\u0627\\u0644\\u0645\\u0628\\u062a\\u062f\\u0626\\u064a\\u0646 \\u0648\\u0630\\u0648\\u064a \\u0627\\u0644\\u062e\\u0628\\u0631\\u0629\\u060c \\u0645\\u0645\\u0627 \\u064a\\u062c\\u0639\\u0644 \\u0627\\u0644\\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a \\u0623\\u0645\\u0631\\u064b\\u0627 \\u0633\\u0647\\u0644\\u0627\\u064b.\"}},\"id\":\"6436f026bdfe0\",\"image\":\"f7676f50-3cc0-4340-99b4-b1cf27f3ab0d.webp\"},\"6436f04798830\":{\"language\":{\"en\":{\"title\":\"Financial Inclusion\",\"sub_title\":\"Access to secure online transactions for everyone, promoting financial inclusion and accessibility.\"},\"es\":{\"title\":\"Inclusi\\u00f3n financiera\",\"sub_title\":\"Acceso a transacciones en l\\u00ednea seguras para todos, promoviendo la inclusi\\u00f3n financiera y la accesibilidad.\"},\"ar\":{\"title\":\"\\u0627\\u0644\\u0634\\u0645\\u0648\\u0644 \\u0627\\u0644\\u0645\\u0627\\u0644\\u064a\",\"sub_title\":\"\\u0627\\u0644\\u0648\\u0635\\u0648\\u0644 \\u0625\\u0644\\u0649 \\u0627\\u0644\\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a \\u0627\\u0644\\u0622\\u0645\\u0646\\u0629 \\u0639\\u0628\\u0631 \\u0627\\u0644\\u0625\\u0646\\u062a\\u0631\\u0646\\u062a \\u0644\\u0644\\u062c\\u0645\\u064a\\u0639\\u060c \\u0648\\u062a\\u0639\\u0632\\u064a\\u0632 \\u0627\\u0644\\u0634\\u0645\\u0648\\u0644 \\u0627\\u0644\\u0645\\u0627\\u0644\\u064a \\u0648\\u0625\\u0645\\u0643\\u0627\\u0646\\u064a\\u0629 \\u0627\\u0644\\u0648\\u0635\\u0648\\u0644.\"}},\"id\":\"6436f04798830\",\"image\":\"038289d5-72ba-43f4-90a7-db86bf8b38f7.webp\"},\"6436f066141b7\":{\"language\":{\"en\":{\"title\":\"Cutting-Edge Security\",\"sub_title\":\"State-of-the-art encryption and security measures to safeguard your data and ensure the highest levels of protection.\"},\"es\":{\"title\":\"Seguridad de vanguardia\",\"sub_title\":\"Cifrado de \\u00faltima generaci\\u00f3n y medidas de seguridad para salvaguardar sus datos y garantizar los m\\u00e1s altos niveles de protecci\\u00f3n.\"},\"ar\":{\"title\":\"\\u0627\\u0644\\u0623\\u0645\\u0646 \\u0627\\u0644\\u0645\\u062a\\u0637\\u0648\\u0631\",\"sub_title\":\"\\u0623\\u062d\\u062f\\u062b \\u0625\\u062c\\u0631\\u0627\\u0621\\u0627\\u062a \\u0627\\u0644\\u062a\\u0634\\u0641\\u064a\\u0631 \\u0648\\u0627\\u0644\\u0623\\u0645\\u0627\\u0646 \\u0644\\u062d\\u0645\\u0627\\u064a\\u0629 \\u0628\\u064a\\u0627\\u0646\\u0627\\u062a\\u0643 \\u0648\\u0636\\u0645\\u0627\\u0646 \\u0623\\u0639\\u0644\\u0649 \\u0645\\u0633\\u062a\\u0648\\u064a\\u0627\\u062a \\u0627\\u0644\\u062d\\u0645\\u0627\\u064a\\u0629.\"}},\"id\":\"6436f066141b7\",\"image\":\"0fbdbbb9-3db8-467c-a26c-613753bc8d41.webp\"},\"6436f088085ab\":{\"language\":{\"en\":{\"title\":\"Transparent Fee Structure\",\"sub_title\":\"A straightforward fee system that ensures you always know what to expect, with no hidden costs.\"},\"es\":{\"title\":\"Estructura de tarifas transparente\",\"sub_title\":\"Un sistema de tarifas sencillo que garantiza que siempre sepa qu\\u00e9 esperar, sin costos ocultos.\"},\"ar\":{\"title\":\"\\u0647\\u064a\\u0643\\u0644 \\u0631\\u0633\\u0648\\u0645 \\u0634\\u0641\\u0627\\u0641\",\"sub_title\":\"\\u0646\\u0638\\u0627\\u0645 \\u0631\\u0633\\u0648\\u0645 \\u0645\\u0628\\u0627\\u0634\\u0631 \\u064a\\u0636\\u0645\\u0646 \\u0644\\u0643 \\u062f\\u0627\\u0626\\u0645\\u064b\\u0627 \\u0645\\u0639\\u0631\\u0641\\u0629 \\u0645\\u0627 \\u064a\\u0645\\u0643\\u0646 \\u062a\\u0648\\u0642\\u0639\\u0647\\u060c \\u062f\\u0648\\u0646 \\u0623\\u064a \\u062a\\u0643\\u0627\\u0644\\u064a\\u0641 \\u0645\\u062e\\u0641\\u064a\\u0629.\"}},\"id\":\"6436f088085ab\",\"image\":\"9444c076-2eeb-460f-bfdd-0c6318439289.webp\"},\"6436f0a8c8891\":{\"language\":{\"en\":{\"title\":\"Constant Innovation\",\"sub_title\":\"Continuous evolution to meet the ever-changing needs of the digital age, offering innovative solutions for seamless transactions.\"},\"es\":{\"title\":\"Innovaci\\u00f3n constante\",\"sub_title\":\"Evoluci\\u00f3n continua para satisfacer las necesidades siempre cambiantes de la era digital, ofreciendo soluciones innovadoras para transacciones fluidas.\"},\"ar\":{\"title\":\"\\u0627\\u0644\\u0627\\u0628\\u062a\\u0643\\u0627\\u0631 \\u0627\\u0644\\u0645\\u0633\\u062a\\u0645\\u0631\",\"sub_title\":\"\\u0627\\u0644\\u062a\\u0637\\u0648\\u0631 \\u0627\\u0644\\u0645\\u0633\\u062a\\u0645\\u0631 \\u0644\\u062a\\u0644\\u0628\\u064a\\u0629 \\u0627\\u0644\\u0627\\u062d\\u062a\\u064a\\u0627\\u062c\\u0627\\u062a \\u0627\\u0644\\u0645\\u062a\\u063a\\u064a\\u0631\\u0629 \\u0644\\u0644\\u0639\\u0635\\u0631 \\u0627\\u0644\\u0631\\u0642\\u0645\\u064a\\u060c \\u0648\\u062a\\u0642\\u062f\\u064a\\u0645 \\u062d\\u0644\\u0648\\u0644 \\u0645\\u0628\\u062a\\u0643\\u0631\\u0629 \\u0644\\u0644\\u0645\\u0639\\u0627\\u0645\\u0644\\u0627\\u062a \\u0627\\u0644\\u0633\\u0644\\u0633\\u0629.\"}},\"id\":\"6436f0a8c8891\",\"image\":\"bc45f214-87ec-4bf6-8f5e-f72f30d3fcfd.webp\"},\"6436f148267e7\":{\"language\":{\"en\":{\"title\":\"24\\/7 Customer Support\",\"sub_title\":\"Round-the-clock assistance from our dedicated support team to address your inquiries and provide help when you need it\"},\"es\":{\"title\":\"Atenci\\u00f3n al cliente 24 horas al d\\u00eda, 7 d\\u00edas a la semana\",\"sub_title\":\"Asistencia las 24 horas del d\\u00eda por parte de nuestro equipo de soporte dedicado para atender sus consultas y brindarle ayuda cuando la necesite\"},\"ar\":{\"title\":\"\\u062f\\u0639\\u0645 \\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621 \\u0639\\u0644\\u0649 \\u0645\\u062f\\u0627\\u0631 24 \\u0633\\u0627\\u0639\\u0629 \\u0637\\u0648\\u0627\\u0644 \\u0623\\u064a\\u0627\\u0645 \\u0627\\u0644\\u0623\\u0633\\u0628\\u0648\\u0639\",\"sub_title\":\"\\u0645\\u0633\\u0627\\u0639\\u062f\\u0629 \\u0639\\u0644\\u0649 \\u0645\\u062f\\u0627\\u0631 \\u0627\\u0644\\u0633\\u0627\\u0639\\u0629 \\u0645\\u0646 \\u0641\\u0631\\u064a\\u0642 \\u0627\\u0644\\u062f\\u0639\\u0645 \\u0627\\u0644\\u0645\\u062e\\u0635\\u0635 \\u0644\\u062f\\u064a\\u0646\\u0627 \\u0644\\u0644\\u0631\\u062f \\u0639\\u0644\\u0649 \\u0627\\u0633\\u062a\\u0641\\u0633\\u0627\\u0631\\u0627\\u062a\\u0643 \\u0648\\u062a\\u0642\\u062f\\u064a\\u0645 \\u0627\\u0644\\u0645\\u0633\\u0627\\u0639\\u062f\\u0629 \\u0639\\u0646\\u062f\\u0645\\u0627 \\u062a\\u062d\\u062a\\u0627\\u062c \\u0625\\u0644\\u064a\\u0647\\u0627\"}},\"id\":\"6436f148267e7\",\"image\":\"4582508c-2041-4829-b970-551aa019c508.webp\"}}}',1,NULL,NULL,'2023-11-06 04:23:29'),(10,'start-section','{\"images\":{\"image\":\"81cf6f08-4def-4bf5-b1dc-327817e4f804.webp\"},\"language\":{\"en\":{\"heading\":\"Ready To Join StripeCard?\",\"button_name\":\"Start Now\",\"button_link\":\"contact\"},\"es\":{\"heading\":\"\\u00bfListo para unirte a StripeCard?\",\"button_name\":\"Empezar ahora\",\"button_link\":\"contact\"},\"ar\":{\"heading\":\"\\u0647\\u0644 \\u0623\\u0646\\u062a \\u0645\\u0633\\u062a\\u0639\\u062f \\u0644\\u0644\\u0627\\u0646\\u0636\\u0645\\u0627\\u0645 \\u0625\\u0644\\u0649 StripeCard\\u061f\",\"button_name\":\"\\u0627\\u0628\\u062f\\u0623 \\u0627\\u0644\\u0622\\u0646\",\"button_link\":\"contact\"}}}',1,NULL,NULL,'2023-11-06 04:28:45'),(11,'blog-section','{\"language\":{\"en\":{\"title\":\"Announcement\",\"heading\":\"Our Recent Announcement\"},\"es\":{\"title\":\"Anuncio\",\"heading\":\"Nuestro anuncio reciente\"},\"ar\":{\"title\":\"\\u0625\\u0639\\u0644\\u0627\\u0646\",\"heading\":\"\\u0625\\u0639\\u0644\\u0627\\u0646\\u0646\\u0627 \\u0627\\u0644\\u0623\\u062e\\u064a\\u0631\"}}}',1,NULL,NULL,'2023-11-06 07:08:07'),(12,'statistics-section','{\"language\":{\"en\":{\"total_users\":\"100\",\"happy_users\":\"1000\",\"total_service\":\"12000\"},\"es\":{\"total_users\":\"100\",\"happy_users\":\"80\",\"total_service\":\"100\"},\"ar\":{\"total_users\":\"100\",\"happy_users\":\"1000\",\"total_service\":\"12000\"}}}',1,NULL,'2023-09-05 03:56:04','2023-11-06 04:19:09');
/*!40000 ALTER TABLE `site_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stripe_virtual_cards`
--

DROP TABLE IF EXISTS `stripe_virtual_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stripe_virtual_cards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `card_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` varchar(28) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `charge` varchar(28) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `maskedPan` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiryMonth` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiryYear` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(1) NOT NULL DEFAULT '1',
  `card_details` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `stripe_virtual_cards_user_id_foreign` (`user_id`),
  CONSTRAINT `stripe_virtual_cards_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stripe_virtual_cards`
--

LOCK TABLES `stripe_virtual_cards` WRITE;
/*!40000 ALTER TABLE `stripe_virtual_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `stripe_virtual_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `strowallet_virtual_cards`
--

DROP TABLE IF EXISTS `strowallet_virtual_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `strowallet_virtual_cards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `name_on_card` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `card_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `card_created_date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `card_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `card_brand` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `card_user_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `card_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `card_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cvv` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiry` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `balance` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `strowallet_virtual_cards_user_id_foreign` (`user_id`),
  CONSTRAINT `strowallet_virtual_cards_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `strowallet_virtual_cards`
--

LOCK TABLES `strowallet_virtual_cards` WRITE;
/*!40000 ALTER TABLE `strowallet_virtual_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `strowallet_virtual_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sudo_virtual_cards`
--

DROP TABLE IF EXISTS `sudo_virtual_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sudo_virtual_cards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `card_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer` text COLLATE utf8mb4_unicode_ci,
  `account` text COLLATE utf8mb4_unicode_ci,
  `fundingSource` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` varchar(28) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `charge` varchar(28) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `maskedPan` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiryMonth` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiryYear` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `billingAddress` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sudo_virtual_cards_user_id_foreign` (`user_id`),
  CONSTRAINT `sudo_virtual_cards_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sudo_virtual_cards`
--

LOCK TABLES `sudo_virtual_cards` WRITE;
/*!40000 ALTER TABLE `sudo_virtual_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `sudo_virtual_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temporary_datas`
--

DROP TABLE IF EXISTS `temporary_datas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temporary_datas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gateway_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temporary_datas`
--

LOCK TABLES `temporary_datas` WRITE;
/*!40000 ALTER TABLE `temporary_datas` DISABLE KEYS */;
INSERT INTO `temporary_datas` VALUES (1,'epusdt','AM35356299',NULL,NULL,'{\"gateway\":19,\"currency\":57,\"amount\":{\"requested_amount\":\"3\",\"sender_cur_code\":\"USD\",\"sender_cur_rate\":1,\"fixed_charge\":0,\"percent_charge\":0,\"total_charge\":0,\"total_amount\":3,\"exchange_rate\":1,\"will_get\":3,\"default_currency\":\"USD\"},\"response\":{\"amount\":3,\"order_id\":\"AM35356299\",\"redirect_url\":\"https:\\/\\/velixpay.com\\/user\\/add-money\\/epusdt\\/callback?gateway=epusdt\",\"notify_url\":\"https:\\/\\/velixpay.com\\/user\\/add-money\\/epusdt\\/notify\",\"signature\":\"6efe5bfb79b06561eac9ed91dbe6ee9a\"}}','2024-09-03 00:24:10','2024-09-03 00:24:10'),(2,'epusdt','AM48669882',NULL,NULL,'{\"gateway\":19,\"currency\":57,\"amount\":{\"requested_amount\":\"1\",\"sender_cur_code\":\"USD\",\"sender_cur_rate\":1,\"fixed_charge\":0,\"percent_charge\":0,\"total_charge\":0,\"total_amount\":1,\"exchange_rate\":1,\"will_get\":1,\"default_currency\":\"USD\"},\"response\":{\"amount\":1,\"order_id\":\"AM48669882\",\"redirect_url\":\"https:\\/\\/velixpay.com\\/user\\/add-money\\/epusdt\\/callback?gateway=epusdt\",\"notify_url\":\"https:\\/\\/velixpay.com\\/user\\/add-money\\/epusdt\\/notify\",\"signature\":\"5180d12ca1828956d030daf5dfc03db1\"}}','2024-09-03 05:16:49','2024-09-03 05:16:49'),(3,'epusdt','AM77192573',NULL,NULL,'{\"gateway\":19,\"currency\":57,\"amount\":{\"requested_amount\":\"1\",\"sender_cur_code\":\"USD\",\"sender_cur_rate\":1,\"fixed_charge\":0,\"percent_charge\":0,\"total_charge\":0,\"total_amount\":1,\"exchange_rate\":1,\"will_get\":1,\"default_currency\":\"USD\"},\"response\":{\"amount\":1,\"order_id\":\"AM77192573\",\"redirect_url\":\"https:\\/\\/velixpay.com\\/user\\/add-money\\/epusdt\\/callback?gateway=epusdt\",\"notify_url\":\"https:\\/\\/velixpay.com\\/api\\/add-money\\/epusdt\\/notify\",\"signature\":\"72b42499f3c41675717201bfe4961a31\"}}','2024-09-03 13:36:53','2024-09-03 13:36:53'),(4,'stripe','TXREF_1725417710',NULL,NULL,'{\"gateway\":2,\"currency\":3,\"amount\":{\"requested_amount\":\"20\",\"sender_cur_code\":\"USD\",\"sender_cur_rate\":1,\"fixed_charge\":2,\"percent_charge\":0.2,\"total_charge\":2.2,\"total_amount\":22.2,\"exchange_rate\":1,\"will_get\":20,\"default_currency\":\"USD\"},\"response\":{\"payment_options\":\"card\",\"amount\":\"22.20\",\"email\":\"sjf110@gmail.com\",\"tx_ref\":\"TXREF_1725417710\",\"currency\":\"USD\",\"redirect_url\":\"https:\\/\\/velixpay.com\\/user\\/add-money\\/stripe\\/payment\\/success\\/TXREF_1725417710\",\"customer\":{\"email\":\"sjf110@gmail.com\",\"phone_number\":\"\",\"name\":\"lariena sun\"},\"customizations\":{\"title\":\"Add Money\",\"description\":\"04 Sep 2024\"}},\"wallet_table\":\"user_wallets\",\"wallet_id\":1,\"creator_table\":\"users\",\"creator_id\":1,\"creator_guard\":\"web\"}','2024-09-04 00:41:51','2024-09-04 00:41:51'),(5,'paypal','443318594P4187213',NULL,NULL,'{\"gateway\":1,\"currency\":2,\"amount\":{\"requested_amount\":\"134\",\"sender_cur_code\":\"AUD\",\"sender_cur_rate\":1.55,\"fixed_charge\":3.1,\"percent_charge\":2.0770000000000004,\"total_charge\":5.1770000000000005,\"total_amount\":212.877,\"exchange_rate\":1,\"will_get\":134,\"default_currency\":\"USD\"},\"response\":{\"id\":\"443318594P4187213\",\"status\":\"CREATED\",\"links\":[{\"href\":\"https:\\/\\/api.sandbox.paypal.com\\/v2\\/checkout\\/orders\\/443318594P4187213\",\"rel\":\"self\",\"method\":\"GET\"},{\"href\":\"https:\\/\\/www.sandbox.paypal.com\\/checkoutnow?token=443318594P4187213\",\"rel\":\"approve\",\"method\":\"GET\"},{\"href\":\"https:\\/\\/api.sandbox.paypal.com\\/v2\\/checkout\\/orders\\/443318594P4187213\",\"rel\":\"update\",\"method\":\"PATCH\"},{\"href\":\"https:\\/\\/api.sandbox.paypal.com\\/v2\\/checkout\\/orders\\/443318594P4187213\\/capture\",\"rel\":\"capture\",\"method\":\"POST\"}]},\"wallet_table\":\"user_wallets\",\"wallet_id\":1,\"creator_table\":\"users\",\"creator_id\":1,\"creator_guard\":\"web\"}','2024-09-04 00:42:20','2024-09-04 00:42:20'),(6,'epusdt','AM45738278',NULL,NULL,'{\"gateway\":19,\"currency\":57,\"amount\":{\"requested_amount\":\"2\",\"sender_cur_code\":\"USD\",\"sender_cur_rate\":1,\"fixed_charge\":0,\"percent_charge\":0,\"total_charge\":0,\"total_amount\":2,\"exchange_rate\":1,\"will_get\":2,\"default_currency\":\"USD\"},\"response\":{\"amount\":2,\"order_id\":\"AM45738278\",\"redirect_url\":\"https:\\/\\/velixpay.com\\/user\\/add-money\\/epusdt\\/success?gateway=epusdt\",\"notify_url\":\"https:\\/\\/velixpay.com\\/user\\/add-money\\/epusdt\\/notify\",\"signature\":\"af209a4cdfbcaa358738a5fe1ac8f757\"},\"wallet_table\":\"user_wallets\",\"wallet_id\":1,\"creator_table\":\"users\",\"creator_id\":1,\"creator_guard\":\"web\"}','2024-09-04 06:11:09','2024-09-04 06:11:09');
/*!40000 ALTER TABLE `temporary_datas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_charges`
--

DROP TABLE IF EXISTS `transaction_charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_charges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` bigint(20) unsigned NOT NULL,
  `percent_charge` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `fixed_charge` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `total_charge` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_charges_transaction_id_foreign` (`transaction_id`),
  CONSTRAINT `transaction_charges_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_charges`
--

LOCK TABLES `transaction_charges` WRITE;
/*!40000 ALTER TABLE `transaction_charges` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction_charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_devices`
--

DROP TABLE IF EXISTS `transaction_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_devices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` bigint(20) unsigned NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mac` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_devices_transaction_id_foreign` (`transaction_id`),
  CONSTRAINT `transaction_devices_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_devices`
--

LOCK TABLES `transaction_devices` WRITE;
/*!40000 ALTER TABLE `transaction_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_settings`
--

DROP TABLE IF EXISTS `transaction_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` bigint(20) unsigned NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fixed_charge` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `percent_charge` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `min_limit` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `max_limit` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `monthly_limit` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `daily_limit` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_settings_admin_id_foreign` (`admin_id`),
  CONSTRAINT `transaction_settings_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_settings`
--

LOCK TABLES `transaction_settings` WRITE;
/*!40000 ALTER TABLE `transaction_settings` DISABLE KEYS */;
INSERT INTO `transaction_settings` VALUES (1,1,'transfer-money','Transfer Money Charge',1.00,1.00,10.00,1000.00,0.00,0.00,1,NULL,NULL),(2,1,'virtual_card','Virtual Card Charges',2.00,1.00,100.00,50000.00,0.00,0.00,1,NULL,NULL),(3,1,'reload_card','Card Reload Charges',2.00,1.00,100.00,50000.00,0.00,0.00,1,NULL,NULL),(4,1,'gift_card','Gift Card Charges',1.00,1.00,2.00,50000.00,0.00,0.00,1,NULL,NULL);
/*!40000 ALTER TABLE `transaction_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `user_wallet_id` bigint(20) unsigned NOT NULL,
  `payment_gateway_currency_id` bigint(20) unsigned DEFAULT NULL,
  `trx_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Transaction ID',
  `request_amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `payable` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `available_balance` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `remark` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `reject_reason` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0: Default, 1: Success, 2: Pending, 3: Hold, 4: Rejected',
  `attribute` enum('SEND','RECEIVED') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `callback_ref` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_admin_id_foreign` (`admin_id`),
  KEY `transactions_user_id_foreign` (`user_id`),
  KEY `transactions_user_wallet_id_foreign` (`user_wallet_id`),
  KEY `transactions_payment_gateway_currency_id_foreign` (`payment_gateway_currency_id`),
  CONSTRAINT `transactions_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `transactions_payment_gateway_currency_id_foreign` FOREIGN KEY (`payment_gateway_currency_id`) REFERENCES `payment_gateway_currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `transactions_user_wallet_id_foreign` FOREIGN KEY (`user_wallet_id`) REFERENCES `user_wallets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_authorizations`
--

DROP TABLE IF EXISTS `user_authorizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_authorizations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `code` int(11) NOT NULL,
  `token` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_authorizations`
--

LOCK TABLES `user_authorizations` WRITE;
/*!40000 ALTER TABLE `user_authorizations` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_authorizations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_kyc_data`
--

DROP TABLE IF EXISTS `user_kyc_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_kyc_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `reject_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_kyc_data_user_id_foreign` (`user_id`),
  CONSTRAINT `user_kyc_data_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_kyc_data`
--

LOCK TABLES `user_kyc_data` WRITE;
/*!40000 ALTER TABLE `user_kyc_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_kyc_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_login_logs`
--

DROP TABLE IF EXISTS `user_login_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_login_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mac` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_login_logs_user_id_foreign` (`user_id`),
  CONSTRAINT `user_login_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_login_logs`
--

LOCK TABLES `user_login_logs` WRITE;
/*!40000 ALTER TABLE `user_login_logs` DISABLE KEYS */;
INSERT INTO `user_login_logs` VALUES (1,1,'119.164.150.225','','Weifang','China','119.162','36.7069','Edge','OS X','Asia/Shanghai','2024-09-03 05:15:07','2024-09-03 05:15:07'),(2,1,'103.36.25.45','','Chang-hua','Taiwan','120.54','24.0676','Chrome','Windows','Asia/Taipei','2024-09-03 13:24:29','2024-09-03 13:24:29'),(3,1,'103.36.25.45','','Chang-hua','Taiwan','120.54','24.0676','Chrome','Windows','Asia/Taipei','2024-09-04 00:41:38','2024-09-04 00:41:38'),(4,1,'103.36.25.45','','Chang-hua','Taiwan','120.54','24.0676','Chrome','Windows','Asia/Taipei','2024-09-04 03:57:16','2024-09-04 03:57:16');
/*!40000 ALTER TABLE `user_login_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_mail_logs`
--

DROP TABLE IF EXISTS `user_mail_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_mail_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_mail_logs_user_id_foreign` (`user_id`),
  CONSTRAINT `user_mail_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_mail_logs`
--

LOCK TABLES `user_mail_logs` WRITE;
/*!40000 ALTER TABLE `user_mail_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_mail_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_notifications`
--

DROP TABLE IF EXISTS `user_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_notifications_user_id_foreign` (`user_id`),
  CONSTRAINT `user_notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_notifications`
--

LOCK TABLES `user_notifications` WRITE;
/*!40000 ALTER TABLE `user_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_password_resets`
--

DROP TABLE IF EXISTS `user_password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_password_resets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` bigint(20) unsigned DEFAULT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_password_resets_token_unique` (`token`),
  UNIQUE KEY `user_password_resets_code_unique` (`code`),
  KEY `user_password_resets_user_id_foreign` (`user_id`),
  CONSTRAINT `user_password_resets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_password_resets`
--

LOCK TABLES `user_password_resets` WRITE;
/*!40000 ALTER TABLE `user_password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profiles`
--

DROP TABLE IF EXISTS `user_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_profiles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `information` text COLLATE utf8mb4_unicode_ci,
  `reject_reason` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_profiles_user_id_foreign` (`user_id`),
  CONSTRAINT `user_profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profiles`
--

LOCK TABLES `user_profiles` WRITE;
/*!40000 ALTER TABLE `user_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_support_chats`
--

DROP TABLE IF EXISTS `user_support_chats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_support_chats` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_support_ticket_id` bigint(20) unsigned NOT NULL,
  `sender` bigint(20) unsigned NOT NULL,
  `sender_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receiver` bigint(20) unsigned DEFAULT NULL,
  `receiver_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_support_chats_user_support_ticket_id_foreign` (`user_support_ticket_id`),
  CONSTRAINT `user_support_chats_user_support_ticket_id_foreign` FOREIGN KEY (`user_support_ticket_id`) REFERENCES `user_support_tickets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_support_chats`
--

LOCK TABLES `user_support_chats` WRITE;
/*!40000 ALTER TABLE `user_support_chats` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_support_chats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_support_ticket_attachments`
--

DROP TABLE IF EXISTS `user_support_ticket_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_support_ticket_attachments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_support_ticket_id` bigint(20) unsigned NOT NULL,
  `attachment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_info` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_support_ticket_attachments_user_support_ticket_id_foreign` (`user_support_ticket_id`),
  CONSTRAINT `user_support_ticket_attachments_user_support_ticket_id_foreign` FOREIGN KEY (`user_support_ticket_id`) REFERENCES `user_support_tickets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_support_ticket_attachments`
--

LOCK TABLES `user_support_ticket_attachments` WRITE;
/*!40000 ALTER TABLE `user_support_ticket_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_support_ticket_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_support_tickets`
--

DROP TABLE IF EXISTS `user_support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_support_tickets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `token` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` text COLLATE utf8mb4_unicode_ci,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0: Default, 1: Solved, 2: Active, 3: Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_support_tickets_token_unique` (`token`),
  KEY `user_support_tickets_user_id_foreign` (`user_id`),
  CONSTRAINT `user_support_tickets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_support_tickets`
--

LOCK TABLES `user_support_tickets` WRITE;
/*!40000 ALTER TABLE `user_support_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_support_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_wallets`
--

DROP TABLE IF EXISTS `user_wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_wallets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `currency_id` bigint(20) unsigned NOT NULL,
  `balance` decimal(28,8) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_wallets_currency_id_foreign` (`currency_id`),
  KEY `user_wallets_user_id_foreign` (`user_id`),
  CONSTRAINT `user_wallets_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_wallets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_wallets`
--

LOCK TABLES `user_wallets` WRITE;
/*!40000 ALTER TABLE `user_wallets` DISABLE KEYS */;
INSERT INTO `user_wallets` VALUES (1,1,1,0.00000000,1,'2024-09-03 00:20:41',NULL);
/*!40000 ALTER TABLE `user_wallets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `refferal_user_id` bigint(20) unsigned DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 = Active, 0 == Banned',
  `address` text COLLATE utf8mb4_unicode_ci,
  `email_verified` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 == Verifiend, 0 == Not verifiend',
  `sms_verified` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 == Verifiend, 0 == Not verifiend',
  `kyc_verified` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: Default, 1: Approved, 2: Pending, 3:Rejected',
  `ver_code` int(11) DEFAULT NULL,
  `ver_code_send_at` timestamp NULL DEFAULT NULL,
  `two_factor_verified` tinyint(1) NOT NULL DEFAULT '0',
  `device_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `sudo_customer` text COLLATE utf8mb4_unicode_ci,
  `sudo_account` text COLLATE utf8mb4_unicode_ci,
  `strowallet_customer` text COLLATE utf8mb4_unicode_ci,
  `stripe_card_holders` text COLLATE utf8mb4_unicode_ci,
  `stripe_connected_account` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_full_mobile_unique` (`full_mobile`),
  KEY `users_mobile_index` (`mobile`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'lariena','sun','lariena','sjf110@gmail.com',NULL,NULL,NULL,'$2y$10$l90HnXAYb9fr9atzpz0iKeI93f2a3FDQT8y03lLrXR.IWp/FrKlVO',NULL,NULL,1,'{\"country\":\"\",\"city\":\"\",\"zip\":\"\",\"state\":\"\",\"address\":\"\"}',1,1,0,NULL,NULL,0,NULL,NULL,NULL,NULL,'2024-09-03 00:20:41','2024-09-03 00:21:16',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtual_card_apis`
--

DROP TABLE IF EXISTS `virtual_card_apis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virtual_card_apis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` bigint(20) unsigned NOT NULL,
  `card_details` text COLLATE utf8mb4_unicode_ci,
  `config` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `image` text COLLATE utf8mb4_unicode_ci,
  `card_limit` int(11) NOT NULL DEFAULT '3',
  PRIMARY KEY (`id`),
  KEY `virtual_card_apis_admin_id_foreign` (`admin_id`),
  CONSTRAINT `virtual_card_apis_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtual_card_apis`
--

LOCK TABLES `virtual_card_apis` WRITE;
/*!40000 ALTER TABLE `virtual_card_apis` DISABLE KEYS */;
INSERT INTO `virtual_card_apis` VALUES (1,1,'<p>This card is property of StripCard, Wonderland. Misuse is criminal offense. If found, please return to StripCard or to the nearest bank.</p>','{\"flutterwave_secret_key\":\"FLWSECK_TEST-SANDBOXDEMOKEY-X\",\"flutterwave_secret_hash\":\"AYxcfvgbhnj@34\",\"flutterwave_url\":\"https:\\/\\/api.flutterwave.com\\/v3\",\"sudo_api_key\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NGI2NWExZmZjM2I2NDM5ZjdkNTZjYzIiLCJlbWFpbEFkZHJlc3MiOiJ1c2VyQGFwcGRldnMubmV0IiwianRpIjoiNjRiNjYyNjdmYzNiNjQzOWY3ZDViZjI2IiwibWVtYmVyc2hpcCI6eyJfaWQiOiI2NGI2NWExZmZjM2I2NDM5ZjdkNTZjYzUiLCJidXNpbmVzcyI6eyJfaWQiOiI2NGI2NWExZmZjM2I2NDM5ZjdkNTZjYzAiLCJuYW1lIjoiQXBwZGV2c1giLCJpc0FwcHJvdmVkIjpmYWxzZX0sInVzZXIiOiI2NGI2NWExZmZjM2I2NDM5ZjdkNTZjYzIiLCJyb2xlIjoiQVBJS2V5In0sImlhdCI6MTY4OTY3NDM0MywiZXhwIjoxNzIxMjMxOTQzfQ.MTKO352CEfxG4SUhpfAWu3mkHilLL8Y-oufD6WWCiH4\",\"sudo_vault_id\":\"tntbuyt0v9u\",\"sudo_url\":\"https:\\/\\/api.sandbox.sudo.cards\",\"sudo_mode\":\"sandbox\",\"stripe_public_key\":\"pk_test_51NjGM4K6kUt0AggqD10PfWJcB8NxJmDhDptSqXPpX2d4Xcj7KtXxIrw1zRgK4jI5SIm9ZB7JIhmeYjcTkF7eL8pc00TgiPUGg5\",\"stripe_secret_key\":\"sk_test_51NjGM4K6kUt0Aggqfejd1Xiixa6HEjQXJNljEwt9QQPOTWoyylaIAhccSBGxWBnvDGw0fptTvGWXJ5kBO7tdpLNG00v5cWHt96\",\"stripe_url\":\"https:\\/\\/api.stripe.com\\/v1\",\"strowallet_public_key\":\"R67MNEPQV2ABQW9HDD7JQFXQ2AJMMY\",\"strowallet_secret_key\":\"AOC963E385FORPRRCXQJ698C1Q953B\",\"strowallet_url\":\"https:\\/\\/strowallet.com\\/api\\/bitvcard\\/\",\"strowallet_mode\":\"sandbox\",\"name\":\"flutterwave\"}','2024-09-02 23:57:50','2024-09-03 00:15:17','seeder/virtual-card.webp',3);
/*!40000 ALTER TABLE `virtual_card_apis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtual_cards`
--

DROP TABLE IF EXISTS `virtual_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virtual_cards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `card_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_hash` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_pan` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `masked_card` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cvv` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_on_card` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `callback` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` varchar(28) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `charge` varchar(28) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bg` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `funding` tinyint(1) NOT NULL DEFAULT '1',
  `terminate` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `virtual_cards_user_id_foreign` (`user_id`),
  CONSTRAINT `virtual_cards_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtual_cards`
--

LOCK TABLES `virtual_cards` WRITE;
/*!40000 ALTER TABLE `virtual_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtual_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'cvvcard'
--

--
-- Dumping routines for database 'cvvcard'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-04 18:18:37
